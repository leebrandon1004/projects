/*
 * Team 13: Garrett Laman, Mark Schneider, Michael Harman, Brandon Lee, Jack Doble
 */

--Query 1 (Mark Schneider) (backup Garrett Laman):
SELECT employee_ID,
       message_contents,
       chat_room_name
FROM chat_message
WHERE employee_ID = '0000000000000001';

/*
Results:

EMPLOYEE_ID      MESSAGE_CONTENTS                                                                 CHAT_ROOM_NAME                                                                                                                  
---------------- -------------------------------------------------------------------------------- --------------------------------------------------------------------------------------------------------------------------------
0000000000000001 This is a test message                                                           Development Channel                                                                                                             
0000000000000001 Looks like it. Probably have to do more testing                                  Development Channel                                                                                                             
0000000000000001 Day two of testing, seems to work fine                                           Development Channel                                                                                                             
0000000000000001 Can someone else try sending a message?                                          Development Channel                                                                                                             
0000000000000001 Thanks                                                                           Development Channel                                                                                                             

*******************************************************************************************************************************/

--Query 2 (Mark Schneider) (backup Garrett Laman):
COL message_contents FORMAT a50;
COL chat_room_name FORMAT a25;
SELECT employee_ID,
       message_contents,
       chat_room_name,
       date_time
FROM chat_message
WHERE date_time BETWEEN '25-MAR-20' AND '27-MAR-20';

/*
Results:

EMPLOYEE_ID      MESSAGE_CONTENTS                                   CHAT_ROOM_NAME            DATE_TIME
---------------- -------------------------------------------------- ------------------------- ---------
0000000000000001 This is a test message                             Development Channel       25-MAR-20
0000000000000002 Did you get the chat system working?               Development Channel       25-MAR-20
0000000000000001 Looks like it. Probably have to do more testing    Development Channel       25-MAR-20
0000000000000002 :thumbsup:                                         Development Channel       25-MAR-20
0000000000000001 Day two of testing, seems to work fine             Development Channel       26-MAR-20
0000000000000001 Can someone else try sending a message?            Development Channel       26-MAR-20
0000000000000003 Yo                                                 Development Channel       26-MAR-20
0000000000000001 Thanks                                             Development Channel       26-MAR-20

8 rows selected. 

*******************************************************************************************************************************/

--Query 3 (Mark Schneider) (backup Garrett Laman):
COL first_name FORMAT a15;
COL last_name FORMAT a15;
SELECT *
FROM employee
WHERE last_name LIKE 'Ma%';

/*
Results:

EMPLOYEE_ID      FIRST_NAME      LAST_NAME       HIRE_DATE BIRTH_DAT PERMITTED_ACCESS_LEVEL
---------------- --------------- --------------- --------- --------- ----------------------
0000000000000006 Eric            Matson          28-OCT-05 04-MAR-69                      7
0000000000000010 Alejandra       Magana          13-AUG-17 08-MAR-80                      8

*******************************************************************************************************************************/

--Query 4 (Mark Schneider) (backup Garrett Laman):
COL hardware_name FORMAT a20;
SELECT hardware_name,
       hardware_price + hardware_shipping AS TOTAL_PRICE
FROM hardware_request;

/*
Results:

HARDWARE_NAME        TOTAL_PRICE
-------------------- -----------
Box of Nails                  14
Screws                        10
2x4 Wood                      28
Custom Wood Frame             35
Hammer                        24
Drill                         12
Metal Hinge                   83
Bolts                         97
Plywood Crate                 14
Nailgun                       15

10 rows selected. 

*******************************************************************************************************************************/

--Query 5 (Mark Schneider) (backup Garrett Laman):
COL name FORMAT a20;
COL city FORMAT a15;
COL state_province FORMAT a15;
COL street_address FORMAT a20;
COL contact_name FORMAT a15;
SELECT *
FROM hardware_vendor
WHERE state_province NOT IN ('FL', 'OH', 'CA');

/*
Results:

VENDOR_ID        NAME                 CITY            STATE_PROVINCE  STREET_ADDRESS       CONTACT_NAME    PHONE      
---------------- -------------------- --------------- --------------- -------------------- --------------- -----------
0000000000000001 Hands Hardy Hardware West Lafayette  IN              Heavilon Hall        Hands, Nicole   7654547899 
0000000000000002 JJ Tools Inc         Kansas City     MO              3321 Bald Street     Jackson, James  5436667890 
0000000000000003 Hammers Deluxe       Tucson          AZ              4563 Hammer Rd       Claw, Bob       5363990367 
0000000000000006 Lumber Co            Boston          MA              8657 Log Drive       Lumber, Jack    9992765543 
0000000000000007 Drill It             Scottsdale      AZ              Rubble Road          Gravel, Tom     5763268754 

*******************************************************************************************************************************/

--Query 6 (Mark Schneider) (backup Garrett Laman):
COL creator FORMAT a15;
SELECT NVL(creator, 'Not specified') AS CREATOR, 
       LPAD(project_name, 20, '*') AS PROJECT_NAME
FROM vc_project;

/*
Results:

CREATOR         PROJECT_NAME        
--------------- --------------------
Not specified   ***Hardware-Ordering
Nicole Hands    *********Collocation
Not specified   ****************Chat
Victor Barlow   **********Neural-Net
Dawn Laux       **************Server
Robert Deadman  ************Frontend
Dominic Kao     ************Database
Eric Matson     *************Support
Guity Ravai     *****Version-Control
Phillip Rawles  *********Maintenance

10 rows selected. 

*******************************************************************************************************************************/

--Query 7 (Garrett Laman) (backup Brandon Lee):
COL EMPLOYEE_ID FORMAT a15;
COL FIRST_NAME FORMAT a15;
COL LAST_NAME FORMAT a15;
COL HIRE_DATE FORMAT a15;
COL BIRTH_DATE FORMAT a15;
COL PERMITTED_ACCESS_LEVEL FORMAT a15;
SELECT EMPLOYEE_ID, FIRST_NAME, LAST_NAME, HIRE_DATE, BIRTH_DATE, PERMITTED_ACCESS_LEVEL
FROM EMPLOYEE
WHERE BIRTH_DATE = (SELECT MIN(BIRTH_DATE)
                    FROM EMPLOYEE);
/*
Results:
EMPLOYEE_ID     FIRST_NAME      LAST_NAME       HIRE_DATE       BIRTH_DATE      PERMITTED_ACCES
--------------- --------------- --------------- --------------- --------------- ---------------
0000000000000007 Guity           Ravai           14-NOV-11       07-SEP-65                     6
*******************************************************************************************************************************/

--Query 8 (Garrett Laman) (backup Brandon Lee):
SELECT COUNT(CHAT_ROOM_NAME), CHAT_ROOM_NAME
FROM CHAT_MESSAGE
GROUP BY CHAT_ROOM_NAME;
/*
Results:
COUNT(CHAT_ROOM_NAME) CHAT_ROOM_NAME                                                                                                                  
--------------------- ---------------------
                    2 General                                                                                                                         
                    1 Admin                                                                                                                           
                    8 Development Channel                                                                                                             
*******************************************************************************************************************************/

--Query 9 (Garrett Laman) (backup Brandon Lee):
SELECT SUM(ACCURACY*TRAINING_DURATION) AS ACCURACY_TIMES_DURATION
FROM CLAIM_NET;
/*
Results:
ACCURACY_TIMES_DURATION
-----------------------
                4451.99
                
I couldn't find any columns that would work better for this.. The calculated field doesn't actually show anything, but there it is
*******************************************************************************************************************************/

--Query 10 (Garrett Laman) (backup Brandon Lee):
SELECT VENDOR_ID, AVG(HARDWARE_PRICE)
FROM HARDWARE_REQUEST
GROUP BY VENDOR_ID;
/*
Results:

VENDOR_ID        AVG(HARDWARE_PRICE)
---------------- -------------------
0000000000000003                  77
0000000000000007                  25
0000000000000002                   8
0000000000000001                  11
0000000000000004                  50
0000000000000010                  20
0000000000000005                   7
0000000000000006                  16
0000000000000008                  10
0000000000000009                   8

10 rows selected. 
*******************************************************************************************************************************/

--Query 11 (Garrett Laman) (backup Brandon Lee):
SELECT CHAT_ROOM_NAME, COUNT(CHAT_ROOM_NAME)
FROM CHAT_MESSAGE
GROUP BY CHAT_ROOM_NAME
HAVING (COUNT(CHAT_ROOM_NAME)> 1);
/*
Result:

CHAT_ROOM_NAME                                           COUNT(CHAT_ROOM_NAME)
-------------------------------------------------------- ---------------------
General                                                  2
Development Channel                                      8
*******************************************************************************************************************************/

--Query 12 (Garrett Laman) (backup Brandon Lee):
SELECT CHAT_ROOM_NAME, COUNT(CHAT_ROOM_NAME)
FROM CHAT_MESSAGE
WHERE DATE_TIME >= '26-MAR-2020'
GROUP BY CHAT_ROOM_NAME
HAVING (COUNT(CHAT_ROOM_NAME)> 1);
/*
Result:
CHAT_ROOM_NAME                                           COUNT(CHAT_ROOM_NAME)
-------------------------------------------------------- ---------------------
General                                                  2
Development Channel                                      4
*******************************************************************************************************************************/

--Query 13 (Brandon Lee) (backup Michael Harman):
select vc_branch.description, vc_project.project_name
from vc_branch
inner join vc_project
on vc_branch.project_name = vc_project.project_name
where vc_branch.project_name = 'Chat' OR vc_branch.project_name = 'Frontend';
/*
Result:

DESCRIPTION                                                                      PROJECT_NAME                                                                                                                                                                                                                                                    
-------------------------------------------------------------------------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
The testing branch for Chat                                                      Chat                                                                                                                                                                                                                                                            
The main branch for Chat                                                         Chat                                                                                                                                                                                                                                                            
The testing branch for the Frontend                                              Frontend                                                                                                                                                                                                                                                        
The main branch for the Frontend                                                 Frontend                                                                                                                                                                                                                                                        
*******************************************************************************************************************************/

--Query 14 (Brandon Lee) (backup Michael Harman):
COL FIRST_NAME FORMAT a15;
COL LAST_NAME FORMAT a15;
COL ORDER_DATE FORMAT a35;

SELECT HARDWARE_REQUEST.REQUEST_ID, TO_CHAR(HARDWARE_REQUEST.DATE_TIME, 'fmMonth DD, YYYY, Day') AS ORDER_DATE, HARDWARE_REQUEST.EMPLOYEE_ID, EMPLOYEE.FIRST_NAME, EMPLOYEE.LAST_NAME
FROM HARDWARE_REQUEST INNER JOIN EMPLOYEE ON HARDWARE_REQUEST.EMPLOYEE_ID = EMPLOYEE.EMPLOYEE_ID
                      INNER JOIN HARDWARE_VENDOR ON HARDWARE_REQUEST.VENDOR_ID = HARDWARE_VENDOR.VENDOR_ID
                      INNER JOIN SERVER ON HARDWARE_REQUEST.REQUEST_ID = SERVER.REQUEST_ID;

/*
Result:
REQUEST_ID       ORDER_DATE                          EMPLOYEE_ID      FIRST_NAME      LAST_NAME      
---------------- ----------------------------------- ---------------- --------------- ---------------
0000000000000007 October 22, 2019, Tuesday           0000000000000004 Robert          Deadman        
0000000000000008 March 8, 2019, Friday               0000000000000003 Dawn            Laux           
0000000000000009 November 5, 2019, Tuesday           0000000000000002 Victor          Barlow         
0000000000000010 June 12, 2019, Wednesday            0000000000000001 Nicole          Hands          
0000000000000006 August 16, 2019, Friday             0000000000000010 Alejandra       Magana         
0000000000000005 October 13, 2019, Sunday            0000000000000009 Ida             Ngambeki       
0000000000000004 January 28, 2019, Monday            0000000000000008 Phillip         Rawles         
0000000000000003 May 13, 2019, Monday                0000000000000007 Guity           Ravai          
0000000000000002 November 24, 2019, Sunday           0000000000000006 Eric            Matson         
0000000000000001 October 12, 2019, Saturday          0000000000000005 Dominic         Kao            

10 rows selected. 
*******************************************************************************************************************************/

--Query 15 (Brandon Lee) (backup Michael Harman):
select project_name, description
from vc_branch
where project_name NOT IN (select project_name from vc_project where project_name = 'Collocation');

/*
Result:
PROJECT_NAME                                                                                                                                                                                                                                                     DESCRIPTION                                                                     
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- --------------------------------------------------------------------------------
Hardware-Ordering                                                                                                                                                                                                                                                The main branch for Hardware                                                    
Hardware-Ordering                                                                                                                                                                                                                                                Fixes the bug where someone cannot order hardware                               
Chat                                                                                                                                                                                                                                                             The main branch for Chat                                                        
Chat                                                                                                                                                                                                                                                             The testing branch for Chat                                                     
Neural-Net                                                                                                                                                                                                                                                       Constantly develop a better Neural Network                                      
Frontend                                                                                                                                                                                                                                                         The main branch for the Frontend                                                
Frontend                                                                                                                                                                                                                                                         The testing branch for the Frontend                                             
Maintenance                                                                                                                                                                                                                                                      Maintenance performed on 04/05/2020                                             

8 rows selected. 
*******************************************************************************************************************************/

--Query 16 (Brandon Lee) (backup Michael Harman):
select AVG(access_level)
from chat_room
where access_level IN (select MAX(access_level) from chat_room);
/*
Result:
AVG(ACCESS_LEVEL)
-----------------
                5
*******************************************************************************************************************************/

--Query 17 (Brandon Lee) (backup Michael Harman):
select AVG(access_level), chat_message.chat_room_name
from chat_room
inner join chat_message on chat_room.chat_room_name = chat_message.chat_room_name
group by chat_message.chat_room_name;
/*
Result:
AVG(ACCESS_LEVEL) CHAT_ROOM_NAME                                                                                                                  
----------------- --------------------------------------------------------------------------------------------------------------------------------
                3 Development Channel                                                                                                             
                1 General                                                                                                                         
                5 Admin                                                                                                                           

*******************************************************************************************************************************/

--Query 18 (Brandon Lee) (backup Michael Harman):
select chat_message.date_time, message_contents
from chat_message
left join hardware_request
on chat_message.date_time = hardware_request.date_time;
/*
Result:
DATE_TIME MESSAGE_CONTENTS                                                                
--------- --------------------------------------------------------------------------------
27-MAR-20 Lets do it                                                                      
26-MAR-20 Day two of testing, seems to work fine                                          
26-MAR-20 Can someone else try sending a message?                                         
26-MAR-20 Yo                                                                              
26-MAR-20 Thanks                                                                          
27-MAR-20 Anyone down for lunch today? Thinking pizza                                     
25-MAR-20 Looks like it. Probably have to do more testing                                 
25-MAR-20 This is a test message                                                          
25-MAR-20 :thumbsup:                                                                      
27-MAR-20 Check out general chat, lunch today if anyone wants it                          
25-MAR-20 Did you get the chat system working?                                            

11 rows selected. 

*******************************************************************************************************************************/

--Query 19 (Michael Harman) (backup Jack Doble):
select chat_room.chat_room_name, message_contents
from chat_room right outer join chat_message on chat_room.chat_room_name = chat_message.chat_room_name;
/*
CHAT_ROOM_NAME                                                                                                                   MESSAGE_CONTENTS                                                                
-------------------------------------------------------------------------------------------------------------------------------- --------------------------------------------------------------------------------
Development Channel                                                                                                              This is a test message                                                          
Development Channel                                                                                                              Did you get the chat system working?                                            
Development Channel                                                                                                              Looks like it. Probably have to do more testing                                 
Development Channel                                                                                                              :thumbsup:                                                                      
Development Channel                                                                                                              Day two of testing, seems to work fine                                          
Development Channel                                                                                                              Can someone else try sending a message?                                         
Development Channel                                                                                                              Yo                                                                              
Development Channel                                                                                                              Thanks                                                                          
General                                                                                                                          Anyone down for lunch today? Thinking pizza                                     
General                                                                                                                          Lets do it                                                                      
Admin                                                                                                                            Check out general chat, lunch today if anyone wants it                          

11 rows selected. 

*************************************************************************************************************************/

--Query 20 (Michael Harman) (backup Jack Doble):
select network_id, dataset_id, accuracy, to_char(training_duration), to_char(null)
from claim_net
union
select network_id, claim_id, cost_of_claim, to_char(username), to_char(date_submitted)
from insurance_claim;
/*
NETWOR DATASET_ID         ACCURACY TO_CHAR(TRAINING_DURATION)                                                                                                                                                                                                                                       TO_CHAR(N
------ ---------------- ---------- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ---------
CN-001 0000000000000001       2800 dgfs322                                                                                                                                                                                                                                                          01-MAR-19
CN-001 DS-001                  .34 654                                                                                                                                                                                                                                                                       
CN-002 0000000000000002       3445 ndkd347                                                                                                                                                                                                                                                          02-MAR-19
CN-002 DS-002                  .76 766                                                                                                                                                                                                                                                                       
CN-003 0000000000000003       6550 ndfj564                                                                                                                                                                                                                                                          03-MAR-19
CN-003 DS-003                  .74 543                                                                                                                                                                                                                                                                       
CN-004 0000000000000004        603 dgfm234                                                                                                                                                                                                                                                          04-MAR-19
CN-004 DS-004                  .54 621                                                                                                                                                                                                                                                                       
CN-005 0000000000000005        467 mbfk256                                                                                                                                                                                                                                                          05-MAR-19
CN-005 DS-005                  .62 754                                                                                                                                                                                                                                                                       
CN-006 0000000000000006        230 nbvg345                                                                                                                                                                                                                                                          06-MAR-19

NETWOR DATASET_ID         ACCURACY TO_CHAR(TRAINING_DURATION)                                                                                                                                                                                                                                       TO_CHAR(N
------ ---------------- ---------- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ---------
CN-006 DS-006                  .89 641                                                                                                                                                                                                                                                                       
CN-007 0000000000000007        340 hjjh235                                                                                                                                                                                                                                                          07-MAR-19
CN-007 DS-007                  .12 788                                                                                                                                                                                                                                                                       
CN-008 0000000000000008        371 hjgj357                                                                                                                                                                                                                                                          08-MAR-19
CN-008 DS-008                  .54 976                                                                                                                                                                                                                                                                       
CN-009 0000000000000009       3250 mjfd356                                                                                                                                                                                                                                                          09-MAR-19
CN-009 DS-009                  .78 765                                                                                                                                                                                                                                                                       
CN-010 0000000000000010       5270 zcgf954                                                                                                                                                                                                                                                          10-MAR-19
CN-010 DS-010                  .83 788                                                                                                                                                                                                                                                                       

20 rows selected. 
*******************************************************************************************************************************/

--Query 21 (Michael Harman) (backup Jack Doble):
select network_id
from claim_net
intersect
select network_id
from insurance_claim;
/*
NETWOR
------
CN-001
CN-002
CN-003
CN-004
CN-005
CN-006
CN-007
CN-008
CN-009
CN-010

10 rows selected. 
*******************************************************************************************************************************/

--Query 22 (Michael Harman) (backup Jack Doble):
--The name was selected based on what street the location is at using a where clause.  Then the name was changes with the update
--set command.
select name
from hardware_vendor
where street_address = '656 Rod Street';
/*
NAME                                                                                                                                                                                                                                                            
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Bills Hard Wood
*/


update hardware_vendor
set name = 'Bills Wood Emporium'
where street_address = '656 Rod Street';
/*

1 row updated.

NAME                                                                                                                                                                                                                                                            
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Bills Wood Emporium
*******************************************************************************************************************************/

--Query 23 (Michael Harman) (backup Jack Doble):
--The city was changed to be Orlando for all shops located in Florida(FL).  This was done using a where clause to filter
--and an update statement to modify.
select city
from hardware_vendor
where state_province= 'FL';
/*
CITY                                                                                                                                                                                                                                                            
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Hialeah
Orlando
Tampa
*/

update hardware_vendor
set city = 'Orlando'
where state_province = 'FL';

/*
3 rows updated.
CITY                                                                                                                                                                                                                                                            
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Orlando
Orlando
Orlando
*******************************************************************************************************************************/

--Query 24 (Michael Harman) (backup Jack Doble):
-- The rows were added with the insert into statement.  The dataset_id
--could not be added with a new Id so an old one was use.  This keeps
--all the keys intact.
select * from claim_net;
/*
NETWOR   ACCURACY TRAINING_DURATION DATASE
------ ---------- ----------------- ------
CN-001        .34               654 DS-001
CN-002        .76               766 DS-002
CN-003        .74               543 DS-003
CN-004        .54               621 DS-004
CN-005        .62               754 DS-005
CN-006        .89               641 DS-006
CN-007        .12               788 DS-007
CN-008        .54               976 DS-008
CN-009        .78               765 DS-009
CN-010        .83               788 DS-010

10 rows selected. */
insert into claim_net 
values ('CN-011', '0.86', '363','DS-010');
insert into claim_net 
values ('CN-012', '0.77', '323','DS-010');
/*
1 row inserted.


1 row inserted.

NETWOR   ACCURACY TRAINING_DURATION DATASE
------ ---------- ----------------- ------
CN-001        .34               654 DS-001
CN-002        .76               766 DS-002
CN-003        .74               543 DS-003
CN-004        .54               621 DS-004
CN-005        .62               754 DS-005
CN-006        .89               641 DS-006
CN-007        .12               788 DS-007
CN-008        .54               976 DS-008
CN-009        .78               765 DS-009
CN-010        .83               788 DS-010
CN-011        .86               363 DS-010

NETWOR   ACCURACY TRAINING_DURATION DATASE
------ ---------- ----------------- ------
CN-012        .77               323 DS-010

12 rows selected. 
*******************************************************************************************************************************/

--Query 25 (Jack Doble) (backup Mark Schneider):
select * 
from server
where server_id = 20;

/*
Before:

SERVER_ID  MAKE            MODEL           SPECIFICATIONS                                                                   DATE_TO_S PROCESSES                                          REQUEST_ID       VENDOR_ID                     
---------- --------------- --------------- -------------------------------------------------------------------------------- --------- -------------------------------------------------- ---------------- ----------------
10         HP              M160            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-DEC-16 Intl,Runtime,Xp                                    0000000000000007 0000000000000004                                                                                                                                                                                                                                                             HP                                                                                                                                                                                                                                                               M160                                                                                                                                                                                                                                                             Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-DEC-16 Intl,Runtime,Xp                                                                                                                                                                                                                                                  0000000000000007 0000000000000004                                                                                                                                                                                                                                                     Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-DEC-16 Intl,Runtime,Xp                                                                                                                                                                                                                                                  0000000000000007 0000000000000004

I am deleting this row because this server is no longer in service.
*/
delete from server
where server_id = 10;

select * 
from server
where server_id = 10;
/*
Result:

1 row deleted.

no rows selected
*******************************************************************************************************************************/

--Query 26 (Jack Doble) (backup Mark Schneider):
select *
from server;
/*
Before:

SERVER_ID  MAKE            MODEL           SPECIFICATIONS                                                                   DATE_TO_S PROCESSES                                          REQUEST_ID       VENDOR_ID                      
---------- --------------- --------------- -------------------------------------------------------------------------------- --------- -------------------------------------------------- ---------------- ---------------- 
20         Dell            M170            Intel Xeon E5-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-NOV-19 Intl,Mgmt,Runtime,Xp                               0000000000000008 0000000000000003         
30         Cisco           M260            Intel Xeon E1-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             23-DEC-16 Intl,Mgmt,Runtime,Xp                               0000000000000009 0000000000000002           
40         Microsoft       M1990           Intel Xeon E2-2635 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             21-MAY-18 Intl,Mgmt,Runtime,Xp                               0000000000000010 0000000000000001       
50         Dell            M170            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-FEB-16 Intl,Mgmt,Runtime                                  0000000000000006 0000000000000005          
60         Dell            M160            Intel Xeon E5-2650 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-AUG-17 Intl,Mgmt,Runtime,Xp                               0000000000000005 0000000000000006         
70         HP              M190            Intel Xeon E2-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             02-DEC-16 Intl,Mgmt,Runtime,Xp                               0000000000000004 0000000000000007          
80         HP              M130            Intel Xeon E4-3630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-DEC-17 Intl,Mgmt,Runtime,Xp                               0000000000000003 0000000000000010          
90         Microsoft       B360            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-DEC-17 Intl,Mgmt,Xp                                       0000000000000002 0000000000000009           
100        HP              M250            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             02-NOV-16 Mgmt,Runtime,Xp                                    0000000000000001 0000000000000008          

9 rows selected. 

Currently there is no telling what operating system version each server has. This new column
allows for better documentation of each server.
*/
alter table server
add operating_system varchar2(256);

select *
from server;
/*
Result:

Table SERVER altered.

SERVER_ID  MAKE            MODEL           SPECIFICATIONS                                                                   DATE_TO_S PROCESSES                                          REQUEST_ID       VENDOR_ID        OPERATING_SYSTEM              
---------- --------------- --------------- -------------------------------------------------------------------------------- --------- -------------------------------------------------- ---------------- ---------------- ------------------------------
20         Dell            M170            Intel Xeon E5-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-NOV-19 Intl,Mgmt,Runtime,Xp                               0000000000000008 0000000000000003           
30         Cisco           M260            Intel Xeon E1-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             23-DEC-16 Intl,Mgmt,Runtime,Xp                               0000000000000009 0000000000000002          
40         Microsoft       M1990           Intel Xeon E2-2635 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             21-MAY-18 Intl,Mgmt,Runtime,Xp                               0000000000000010 0000000000000001      
50         Dell            M170            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-FEB-16 Intl,Mgmt,Runtime                                  0000000000000006 0000000000000005       
60         Dell            M160            Intel Xeon E5-2650 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-AUG-17 Intl,Mgmt,Runtime,Xp                               0000000000000005 0000000000000006       
70         HP              M190            Intel Xeon E2-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             02-DEC-16 Intl,Mgmt,Runtime,Xp                               0000000000000004 0000000000000007           
80         HP              M130            Intel Xeon E4-3630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-DEC-17 Intl,Mgmt,Runtime,Xp                               0000000000000003 0000000000000010        
90         Microsoft       B360            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-DEC-17 Intl,Mgmt,Xp                                       0000000000000002 0000000000000009      
100        HP              M250            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             02-NOV-16 Mgmt,Runtime,Xp                                    0000000000000001 0000000000000008         

9 rows selected. 
*******************************************************************************************************************************/

--Query 27 (Jack Doble) (backup Mark Schneider):
select *
from server;
/*
Before:

SERVER_ID  MAKE            MODEL           SPECIFICATIONS                                                                   DATE_TO_S PROCESSES                                          REQUEST_ID       VENDOR_ID        OPERATING_SYSTEM              
---------- --------------- --------------- -------------------------------------------------------------------------------- --------- -------------------------------------------------- ---------------- ---------------- ------------------------------
20         Dell            M170            Intel Xeon E5-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-NOV-19 Intl,Mgmt,Runtime,Xp                               0000000000000008 0000000000000003           
30         Cisco           M260            Intel Xeon E1-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             23-DEC-16 Intl,Mgmt,Runtime,Xp                               0000000000000009 0000000000000002          
40         Microsoft       M1990           Intel Xeon E2-2635 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             21-MAY-18 Intl,Mgmt,Runtime,Xp                               0000000000000010 0000000000000001      
50         Dell            M170            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-FEB-16 Intl,Mgmt,Runtime                                  0000000000000006 0000000000000005       
60         Dell            M160            Intel Xeon E5-2650 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-AUG-17 Intl,Mgmt,Runtime,Xp                               0000000000000005 0000000000000006       
70         HP              M190            Intel Xeon E2-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             02-DEC-16 Intl,Mgmt,Runtime,Xp                               0000000000000004 0000000000000007           
80         HP              M130            Intel Xeon E4-3630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-DEC-17 Intl,Mgmt,Runtime,Xp                               0000000000000003 0000000000000010        
90         Microsoft       B360            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-DEC-17 Intl,Mgmt,Xp                                       0000000000000002 0000000000000009      
100        HP              M250            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             02-NOV-16 Mgmt,Runtime,Xp                                    0000000000000001 0000000000000008         

9 rows selected. 

Each row will be updated to show each server has Debian Server 10.3.0 installed.
*/
update server
set operating_system = 'Debian Server 10.3.0';

select *
from server;
/*
Result:

SERVER_ID  MAKE            MODEL           SPECIFICATIONS                                                                   DATE_TO_S PROCESSES                                          REQUEST_ID       VENDOR_ID        OPERATING_SYSTEM              
---------- --------------- --------------- -------------------------------------------------------------------------------- --------- -------------------------------------------------- ---------------- ---------------- ------------------------------
20         Dell            M170            Intel Xeon E5-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-NOV-19 Intl,Mgmt,Runtime,Xp                               0000000000000008 0000000000000003 Debian Server 10.3.0          
30         Cisco           M260            Intel Xeon E1-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             23-DEC-16 Intl,Mgmt,Runtime,Xp                               0000000000000009 0000000000000002 Debian Server 10.3.0          
40         Microsoft       M1990           Intel Xeon E2-2635 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             21-MAY-18 Intl,Mgmt,Runtime,Xp                               0000000000000010 0000000000000001 Debian Server 10.3.0          
50         Dell            M170            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-FEB-16 Intl,Mgmt,Runtime                                  0000000000000006 0000000000000005 Debian Server 10.3.0          
60         Dell            M160            Intel Xeon E5-2650 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-AUG-17 Intl,Mgmt,Runtime,Xp                               0000000000000005 0000000000000006 Debian Server 10.3.0          
70         HP              M190            Intel Xeon E2-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             02-DEC-16 Intl,Mgmt,Runtime,Xp                               0000000000000004 0000000000000007 Debian Server 10.3.0          
80         HP              M130            Intel Xeon E4-3630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-DEC-17 Intl,Mgmt,Runtime,Xp                               0000000000000003 0000000000000010 Debian Server 10.3.0          
90         Microsoft       M360            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-DEC-17 Intl,Mgmt,Xp                                       0000000000000002 0000000000000009 Debian Server 10.3.0          
100        HP              M250            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             02-NOV-16 Mgmt,Runtime,Xp                                    0000000000000001 0000000000000008 Debian Server 10.3.0          

9 rows selected. 
/******************************************************************************************************************************/

--Query 28 (Jack Doble) (backup Mark Schneider):
select *
from server;
/*
Before:

SERVER_ID  MAKE            MODEL           SPECIFICATIONS                                                                   DATE_TO_S PROCESSES                                          REQUEST_ID       VENDOR_ID        OPERATING_SYSTEM              
---------- --------------- --------------- -------------------------------------------------------------------------------- --------- -------------------------------------------------- ---------------- ---------------- ------------------------------
20         Dell            M170            Intel Xeon E5-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-NOV-19 Intl,Mgmt,Runtime,Xp                               0000000000000008 0000000000000003 Debian Server 10.3.0          
30         Cisco           M260            Intel Xeon E1-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             23-DEC-16 Intl,Mgmt,Runtime,Xp                               0000000000000009 0000000000000002 Debian Server 10.3.0          
40         Microsoft       M1990           Intel Xeon E2-2635 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             21-MAY-18 Intl,Mgmt,Runtime,Xp                               0000000000000010 0000000000000001 Debian Server 10.3.0          
50         Dell            M170            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-FEB-16 Intl,Mgmt,Runtime                                  0000000000000006 0000000000000005 Debian Server 10.3.0          
60         Dell            M160            Intel Xeon E5-2650 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-AUG-17 Intl,Mgmt,Runtime,Xp                               0000000000000005 0000000000000006 Debian Server 10.3.0          
70         HP              M190            Intel Xeon E2-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             02-DEC-16 Intl,Mgmt,Runtime,Xp                               0000000000000004 0000000000000007 Debian Server 10.3.0          
80         HP              M130            Intel Xeon E4-3630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-DEC-17 Intl,Mgmt,Runtime,Xp                               0000000000000003 0000000000000010 Debian Server 10.3.0          
90         Microsoft       M360            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-DEC-17 Intl,Mgmt,Xp                                       0000000000000002 0000000000000009 Debian Server 10.3.0          
100        HP              M250            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             02-NOV-16 Mgmt,Runtime,Xp                                    0000000000000001 0000000000000008 Debian Server 10.3.0          

9 rows selected. 

This record was updated to reflect a change to a different server model.
*/
update server
set model = 'B' || substr(model,2,length(model))
where server_id = 90;

COLUMN server_id FORMAT A10;
COLUMN make FORMAT A15;
COLUMN model FORMAT A15;
COLUMN processes FORMAT A30;
COLUMN operating_system FORMAT A30;

select *
from server;
/*
Result:

SERVER_ID  MAKE            MODEL           SPECIFICATIONS                                                                   DATE_TO_S PROCESSES                                          REQUEST_ID       VENDOR_ID        OPERATING_SYSTEM              
---------- --------------- --------------- -------------------------------------------------------------------------------- --------- -------------------------------------------------- ---------------- ---------------- ------------------------------
20         Dell            M170            Intel Xeon E5-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-NOV-19 Intl,Mgmt,Runtime,Xp                               0000000000000008 0000000000000003 Debian Server 10.3.0          
30         Cisco           M260            Intel Xeon E1-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             23-DEC-16 Intl,Mgmt,Runtime,Xp                               0000000000000009 0000000000000002 Debian Server 10.3.0          
40         Microsoft       M1990           Intel Xeon E2-2635 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             21-MAY-18 Intl,Mgmt,Runtime,Xp                               0000000000000010 0000000000000001 Debian Server 10.3.0          
50         Dell            M170            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-FEB-16 Intl,Mgmt,Runtime                                  0000000000000006 0000000000000005 Debian Server 10.3.0          
60         Dell            M160            Intel Xeon E5-2650 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-AUG-17 Intl,Mgmt,Runtime,Xp                               0000000000000005 0000000000000006 Debian Server 10.3.0          
70         HP              M190            Intel Xeon E2-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             02-DEC-16 Intl,Mgmt,Runtime,Xp                               0000000000000004 0000000000000007 Debian Server 10.3.0          
80         HP              M130            Intel Xeon E4-3630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-DEC-17 Intl,Mgmt,Runtime,Xp                               0000000000000003 0000000000000010 Debian Server 10.3.0          
90         Microsoft       B360            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-DEC-17 Intl,Mgmt,Xp                                       0000000000000002 0000000000000009 Debian Server 10.3.0          
100        HP              M250            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             02-NOV-16 Mgmt,Runtime,Xp                                    0000000000000001 0000000000000008 Debian Server 10.3.0          

9 rows selected. 
*******************************************************************************************************************************/

--Query 29 (Jack Doble) (backup Mark Schneider):
create view projects2020 as
select project_name, creator, creation_date, url, description
from vc_project
where creation_date between '1-JAN-20' and '31-DEC-2020';

create index creator_index
on vc_project (creator);

create unique index creationdate_index
on vc_project (creation_date);

COLUMN project_name FORMAT A20;
COLUMN creator FORMAT A20;
COLUMN url FORMAT A90;
COLUMN description FORMAT A400;

select *
from vc_project;
/*
Result:

PROJECT_NAME         CREATOR              CREATION_ URL                                                                                        DESCRIPTION                                                                                                                                                                                                                                                                                                                                                                                                     
-------------------- -------------------- --------- ------------------------------------------------------------------------------------------ ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Hardware-Ordering                                   https://github.com/BoilerSolutions/MSAS/projects/1                                         Anything related to Hardware Ordering. This is where issues involving the Hardware Ordering System will be fixed.                                                                                                                                                                                                                                                                                               
Collocation          Nicole Hands         27-APR-18                                                                                            Anything related to Collocation. This is where problems related to Collocation not working will be fixed.                                                                                                                                                                                                                                                                                                       
Chat                                      20-NOV-18 https://github.com/BoilerSolutions/MSAS/projects/3                                         Anything related to the Chat. This is where new features will be added so users can better communicate.                                                                                                                                                                                                                                                                                                         
Neural-Net           Victor Barlow        26-JUL-18 https://github.com/BoilerSolutions/MSAS/projects/4                                         Anything related to the Neural Net. This is where the Neural Network will be trained and used.                                                                                                                                                                                                                                                                                                                  
Server               Dawn Laux            02-FEB-16                                                                                            Anything related to the Servers. This could involve specs or status of the servers.                                                                                                                                                                                                                                                                                                                             
Frontend             Robert Deadman                 https://github.com/BoilerSolutions/MSAS/projects/6                                         Anything related to the Frontend of the service. This is where the website development happens.                                                                                                                                                                                                                                                                                                                 
Database             Dominic Kao          10-SEP-17                                                                                            Anything related to the Database. This could involve adding items to it or doing a new version.                                                                                                                                                                                                                                                                                                                 
Support              Eric Matson          23-AUG-20                                                                                            Anything related to the Support of users. This is where the support team will interact with customers.                                                                                                                                                                                                                                                                                                          
Version-Control      Guity Ravai          18-DEC-19 https://github.com/BoilerSolutions/MSAS/projects/9                                         Anything related to Version Control. This could be errors or collaboration requests.                                                                                                                                                                                                                                                                                                                            
Maintenance          Phillip Rawles       02-APR-15 https://github.com/BoilerSolutions/MSAS/projects/10                                        Anything related to the Maintenance of the system.                                                                                                                                                                                                                                                                                                                                                              

10 rows selected. 
*******************************************************************************************************************************/

--Query 30 (Jack Doble) (backup Mark Schneider):
COLUMN first_name FORMAT A20;
COLUMN last_name FORMAT A20;

select first_name,last_name,permitted_access_level
from employee
where permitted_access_level in (7,8,9);
/*
Result:

 FIRST_NAME           LAST_NAME            PERMITTED_ACCESS_LEVEL
-------------------- -------------------- ----------------------
Dawn                 Laux                                      9
Dominic              Kao                                       9
Eric                 Matson                                    7
Alejandra            Magana                                    8                                                                                                                                                                                                                                                    Magana                                                                                                                                                                                                                                                                                8
*******************************************************************************************************************************/