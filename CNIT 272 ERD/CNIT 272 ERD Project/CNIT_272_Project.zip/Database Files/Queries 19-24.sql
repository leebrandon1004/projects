--19.
select chat_room.chat_room_name, message_contents
from chat_room right outer join chat_message on chat_room.chat_room_name = chat_message.chat_room_name;
/*
CHAT_ROOM_NAME                                                                                                                   MESSAGE_CONTENTS                                                                
-------------------------------------------------------------------------------------------------------------------------------- --------------------------------------------------------------------------------
Development Channel                                                                                                              This is a test message                                                          
Development Channel                                                                                                              Did you get the chat system working?                                            
Development Channel                                                                                                              Looks like it. Probably have to do more testing                                 
Development Channel                                                                                                              :thumbsup:                                                                      
Development Channel                                                                                                              Day two of testing, seems to work fine                                          
Development Channel                                                                                                              Can someone else try sending a message?                                         
Development Channel                                                                                                              Yo                                                                              
Development Channel                                                                                                              Thanks                                                                          
General                                                                                                                          Anyone down for lunch today? Thinking pizza                                     
General                                                                                                                          Lets do it                                                                      
Admin                                                                                                                            Check out general chat, lunch today if anyone wants it                          

11 rows selected. 

*/
--20.
select network_id, dataset_id, accuracy, to_char(training_duration), to_char(null)
from claim_net
union
select network_id, claim_id, cost_of_claim, to_char(username), to_char(date_submitted)
from insurance_claim;
/*
NETWOR DATASET_ID         ACCURACY TO_CHAR(TRAINING_DURATION)                                                                                                                                                                                                                                       TO_CHAR(N
------ ---------------- ---------- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ---------
CN-001 0000000000000001       2800 dgfs322                                                                                                                                                                                                                                                          01-MAR-19
CN-001 DS-001                  .34 654                                                                                                                                                                                                                                                                       
CN-002 0000000000000002       3445 ndkd347                                                                                                                                                                                                                                                          02-MAR-19
CN-002 DS-002                  .76 766                                                                                                                                                                                                                                                                       
CN-003 0000000000000003       6550 ndfj564                                                                                                                                                                                                                                                          03-MAR-19
CN-003 DS-003                  .74 543                                                                                                                                                                                                                                                                       
CN-004 0000000000000004        603 dgfm234                                                                                                                                                                                                                                                          04-MAR-19
CN-004 DS-004                  .54 621                                                                                                                                                                                                                                                                       
CN-005 0000000000000005        467 mbfk256                                                                                                                                                                                                                                                          05-MAR-19
CN-005 DS-005                  .62 754                                                                                                                                                                                                                                                                       
CN-006 0000000000000006        230 nbvg345                                                                                                                                                                                                                                                          06-MAR-19

NETWOR DATASET_ID         ACCURACY TO_CHAR(TRAINING_DURATION)                                                                                                                                                                                                                                       TO_CHAR(N
------ ---------------- ---------- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ---------
CN-006 DS-006                  .89 641                                                                                                                                                                                                                                                                       
CN-007 0000000000000007        340 hjjh235                                                                                                                                                                                                                                                          07-MAR-19
CN-007 DS-007                  .12 788                                                                                                                                                                                                                                                                       
CN-008 0000000000000008        371 hjgj357                                                                                                                                                                                                                                                          08-MAR-19
CN-008 DS-008                  .54 976                                                                                                                                                                                                                                                                       
CN-009 0000000000000009       3250 mjfd356                                                                                                                                                                                                                                                          09-MAR-19
CN-009 DS-009                  .78 765                                                                                                                                                                                                                                                                       
CN-010 0000000000000010       5270 zcgf954                                                                                                                                                                                                                                                          10-MAR-19
CN-010 DS-010                  .83 788                                                                                                                                                                                                                                                                       

20 rows selected. 
*/
--21.
select network_id
from claim_net
intersect
select network_id
from insurance_claim;
/*
NETWOR
------
CN-001
CN-002
CN-003
CN-004
CN-005
CN-006
CN-007
CN-008
CN-009
CN-010

10 rows selected. 
*/

--The name was selected based on what street the location is at using a where clause.  Then the name was changes with the update
--set command.
select name
from hardware_vendor
where street_address = '656 Rod Street';
/*
1 row updated.
NAME                                                                                                                                                                                                                                                            
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Bills Hard Wood
*/


update hardware_vendor
set name = 'Bills Wood Emporium'
where street_address = '656 Rod Street';
/*
NAME                                                                                                                                                                                                                                                            
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Bills Wood Emporium
*/
--23.
--The city was changed to be Orlando for all shops located in Florida(FL).  This was done using a where clause to filter
--and an update statement to modify.
select city
from hardware_vendor
where state_province= 'FL';
/*
CITY                                                                                                                                                                                                                                                            
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Hialeah
Orlando
Tampa
*/

update hardware_vendor
set city = 'Orlando'
where state_province = 'FL';

/*
3 rows updated.
CITY                                                                                                                                                                                                                                                            
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Orlando
Orlando
Orlando
*/

--24.
-- The rows were added with the insert into statement.  The dataset_id
--could not be added with a new Id so an old one was use.  This keeps
--all the keys intact.
select * from claim_net;
/*
NETWOR   ACCURACY TRAINING_DURATION DATASE
------ ---------- ----------------- ------
CN-001        .34               654 DS-001
CN-002        .76               766 DS-002
CN-003        .74               543 DS-003
CN-004        .54               621 DS-004
CN-005        .62               754 DS-005
CN-006        .89               641 DS-006
CN-007        .12               788 DS-007
CN-008        .54               976 DS-008
CN-009        .78               765 DS-009
CN-010        .83               788 DS-010

10 rows selected. */
insert into claim_net 
values ('CN-011', '0.86', '363','DS-010');
insert into claim_net 
values ('CN-012', '0.77', '323','DS-010');
/*
1 row inserted.


1 row inserted.

NETWOR   ACCURACY TRAINING_DURATION DATASE
------ ---------- ----------------- ------
CN-001        .34               654 DS-001
CN-002        .76               766 DS-002
CN-003        .74               543 DS-003
CN-004        .54               621 DS-004
CN-005        .62               754 DS-005
CN-006        .89               641 DS-006
CN-007        .12               788 DS-007
CN-008        .54               976 DS-008
CN-009        .78               765 DS-009
CN-010        .83               788 DS-010
CN-011        .86               363 DS-010

NETWOR   ACCURACY TRAINING_DURATION DATASE
------ ---------- ----------------- ------
CN-012        .77               323 DS-010

12 rows selected. 
*/