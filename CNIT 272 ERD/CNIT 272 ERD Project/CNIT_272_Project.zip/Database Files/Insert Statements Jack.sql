insert into training_dataset values ('DS-001',to_date('03-11-2019', 'MM-DD-YYYY'), '\\MEDICS\ClaimNet\Datasets\DS-001\', '0000000000000001');
insert into training_dataset values ('DS-002',to_date('03-12-2019', 'MM-DD-YYYY'), '\\MEDICS\ClaimNet\Datasets\DS-002\', '0000000000000002');
insert into training_dataset values ('DS-003',to_date('03-13-2019', 'MM-DD-YYYY'), '\\MEDICS\ClaimNet\Datasets\DS-003\', '0000000000000003');
insert into training_dataset values ('DS-004',to_date('03-14-2019', 'MM-DD-YYYY'), '\\MEDICS\ClaimNet\Datasets\DS-004\', '0000000000000004');
insert into training_dataset values ('DS-005',to_date('03-15-2019', 'MM-DD-YYYY'), '\\MEDICS\ClaimNet\Datasets\DS-005\', '0000000000000005');
insert into training_dataset values ('DS-006',to_date('03-16-2019', 'MM-DD-YYYY'), '\\MEDICS\ClaimNet\Datasets\DS-006\', '0000000000000006');
insert into training_dataset values ('DS-007',to_date('03-17-2019', 'MM-DD-YYYY'), '\\MEDICS\ClaimNet\Datasets\DS-007\', '0000000000000007');
insert into training_dataset values ('DS-008',to_date('03-18-2019', 'MM-DD-YYYY'), '\\MEDICS\ClaimNet\Datasets\DS-008\', '0000000000000008');
insert into training_dataset values ('DS-009',to_date('03-19-2019', 'MM-DD-YYYY'), '\\MEDICS\ClaimNet\Datasets\DS-009\', '0000000000000009');
insert into training_dataset values ('DS-010',to_date('03-20-2019', 'MM-DD-YYYY'), '\\MEDICS\ClaimNet\Datasets\DS-010\', '0000000000000010');

insert into claim_net values ('CN-001', .34, 654, 'DS-001');
insert into claim_net values ('CN-002', .76, 766, 'DS-002');
insert into claim_net values ('CN-003', .74, 543, 'DS-003');
insert into claim_net values ('CN-004', .54, 621, 'DS-004');
insert into claim_net values ('CN-005', .62, 754, 'DS-005');
insert into claim_net values ('CN-006', .89, 641, 'DS-006');
insert into claim_net values ('CN-007', .12, 788, 'DS-007');
insert into claim_net values ('CN-008', .54, 976, 'DS-008');
insert into claim_net values ('CN-009', .78, 765, 'DS-009');
insert into claim_net values ('CN-010', .83, 788, 'DS-010');

insert into insurance_claim values ('0000000000000001', 'dgfs322', 2800, to_date('03-01-2019', 'MM-DD-YYYY'), 'CN-001');
insert into insurance_claim values ('0000000000000002', 'ndkd347', 3445, to_date('03-02-2019', 'MM-DD-YYYY'), 'CN-002');
insert into insurance_claim values ('0000000000000003', 'ndfj564', 6550, to_date('03-03-2019', 'MM-DD-YYYY'), 'CN-003');
insert into insurance_claim values ('0000000000000004', 'dgfm234', 603, to_date('03-04-2019', 'MM-DD-YYYY'), 'CN-004');
insert into insurance_claim values ('0000000000000005', 'mbfk256', 467, to_date('03-05-2019', 'MM-DD-YYYY'), 'CN-005');
insert into insurance_claim values ('0000000000000006', 'nbvg345', 230, to_date('03-06-2019', 'MM-DD-YYYY'), 'CN-006');
insert into insurance_claim values ('0000000000000007', 'hjjh235', 340, to_date('03-07-2019', 'MM-DD-YYYY'), 'CN-007');
insert into insurance_claim values ('0000000000000008', 'hjgj357', 371, to_date('03-08-2019', 'MM-DD-YYYY'), 'CN-008');
insert into insurance_claim values ('0000000000000009', 'mjfd356', 3250, to_date('03-09-2019', 'MM-DD-YYYY'), 'CN-009');
insert into insurance_claim values ('0000000000000010', 'zcgf954', 5270, to_date('03-10-2019', 'MM-DD-YYYY'), 'CN-010');


