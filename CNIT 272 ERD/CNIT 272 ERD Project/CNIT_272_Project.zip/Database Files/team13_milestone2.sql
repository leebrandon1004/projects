/*
 * Team 13: Garrett Laman, Mark Schneider, Michael Harman, Brandon Lee, Jack Doble
 */

DROP TABLE CHAT_MESSAGE     CASCADE CONSTRAINTS;
DROP TABLE CHAT_ROOM        CASCADE CONSTRAINTS;
DROP TABLE CLAIM_NET        CASCADE CONSTRAINTS;
DROP TABLE EMPLOYEE         CASCADE CONSTRAINTS;
DROP TABLE HARDWARE_REQUEST CASCADE CONSTRAINTS;
DROP TABLE HARDWARE_VENDOR  CASCADE CONSTRAINTS;
DROP TABLE INSURANCE_CLAIM  CASCADE CONSTRAINTS;
DROP TABLE SERVER           CASCADE CONSTRAINTS;
DROP TABLE SUPPORT_TICKET   CASCADE CONSTRAINTS;
DROP TABLE TRAINING_DATASET CASCADE CONSTRAINTS;
DROP TABLE VC_BRANCH        CASCADE CONSTRAINTS;
DROP TABLE VC_COMMIT        CASCADE CONSTRAINTS;
DROP TABLE VC_ISSUE         CASCADE CONSTRAINTS;
DROP TABLE VC_PROJECT       CASCADE CONSTRAINTS;

CREATE TABLE employee (
    employee_id             CHAR(16) NOT NULL,
    first_name              VARCHAR2(256),
    last_name               VARCHAR2(256),
    hire_date               DATE,
    birth_date              DATE,
    permitted_access_level  INTEGER,
    CONSTRAINT employee_pk PRIMARY KEY ( employee_id )
);

CREATE TABLE vc_project (
    project_name   VARCHAR2(256) NOT NULL,
    creator        VARCHAR2(256),
    creation_date  DATE,
    url            VARCHAR2(512),
    description    LONG,
    CONSTRAINT vc_project_pk PRIMARY KEY ( project_name )
);

CREATE TABLE vc_branch (
    branch_name   VARCHAR2(256) NOT NULL,
    description   LONG,
    url           VARCHAR2(256),
    project_name  VARCHAR2(256) NOT NULL,
    CONSTRAINT vc_branch_pk PRIMARY KEY ( project_name, branch_name ),
    CONSTRAINT vc_branch_vc_project_fk 
        FOREIGN KEY ( project_name ) REFERENCES vc_project ( project_name )
);

CREATE TABLE vc_commit (
    commit_id      CHAR(16) NOT NULL,
    branch_name    VARCHAR2(256) NOT NULL,
    description    VARCHAR2(1024),
    date_time      DATE,
    source_code    VARCHAR2(1024),
    files_changed  VARCHAR2(1024),
    change_reason  VARCHAR2(1024),
    employee_id    CHAR(16) NOT NULL,
    project_name   VARCHAR2(256) NOT NULL,
    CONSTRAINT vc_commit_pk PRIMARY KEY ( commit_id ),
    CONSTRAINT vc_commit_employee_fk 
        FOREIGN KEY ( employee_id ) REFERENCES employee ( employee_id ),
    CONSTRAINT vc_commit_vc_branch_fk 
        FOREIGN KEY ( project_name, branch_name ) REFERENCES vc_branch ( project_name, branch_name )
);

CREATE TABLE vc_issue (
    issue_id      CHAR(16) NOT NULL,
    submitter     VARCHAR2(256) NOT NULL,
    description   LONG,
    severity      INTEGER,
    category      VARCHAR2(32),
    assignee      VARCHAR2(256),
    project_name  VARCHAR2(256) NOT NULL,
    branch_name   VARCHAR2(256) NOT NULL,
    CONSTRAINT vc_issue_pk PRIMARY KEY ( issue_id ),
    CONSTRAINT vc_issue_vc_branch_fk 
        FOREIGN KEY ( project_name, branch_name ) REFERENCES vc_branch ( project_name, branch_name )
);

CREATE TABLE support_ticket (
    ticket_id            CHAR(16) NOT NULL,
    submitted_by         VARCHAR2(256),
    date_time_submitted  DATE,
    description          LONG,
    assignee             VARCHAR2(256),
    employee_id          CHAR(16) NOT NULL,  
    project_name         VARCHAR2(256) NOT NULL,
    branch_name          VARCHAR2(256) NOT NULL,
    issue_id             CHAR(16) NOT NULL,
    CONSTRAINT support_ticket_pk PRIMARY KEY ( ticket_id ),
    CONSTRAINT support_ticket_employee_fk 
        FOREIGN KEY ( employee_id ) REFERENCES employee ( employee_id ),
    CONSTRAINT support_ticket_vc_issue_fk 
        FOREIGN KEY ( issue_id ) REFERENCES vc_issue ( issue_id )
);

CREATE TABLE hardware_vendor (
    vendor_id       CHAR(16) NOT NULL,
    name            VARCHAR2(256),
    city            VARCHAR2(256),
    state_province  VARCHAR2(256),
    street_address  VARCHAR2(256),
    contact_name    VARCHAR2(256),
    phone           CHAR(11),
    CONSTRAINT hardware_vendor_pk PRIMARY KEY ( vendor_id )
);

CREATE TABLE chat_room (
    chat_room_name  VARCHAR2(128) NOT NULL,
    access_level    INTEGER,
    creation_date   DATE,
    CONSTRAINT chat_room_pk PRIMARY KEY ( chat_room_name )
);

CREATE TABLE chat_message (
    date_time         DATE NOT NULL,
    employee_id       CHAR(16) NOT NULL,
    message_contents  LONG NOT NULL,
    chat_room_name    VARCHAR2(128) NOT NULL,
    CONSTRAINT chat_message_pk PRIMARY KEY ( employee_id, date_time ),
    CONSTRAINT chat_message_chat_room_fk 
        FOREIGN KEY ( chat_room_name ) REFERENCES chat_room ( chat_room_name ),
    CONSTRAINT chat_message_employee_fk 
        FOREIGN KEY ( employee_id ) REFERENCES employee ( employee_id )
);

CREATE TABLE training_dataset (
    dataset_id      CHAR(6) NOT NULL,
    date_time       DATE,
    data_directory  VARCHAR2(256),
    employee_id     CHAR(16) NOT NULL,
    CONSTRAINT training_dataset_pk PRIMARY KEY ( dataset_id ),
    CONSTRAINT training_dataset_employee_fk 
        FOREIGN KEY ( employee_id ) REFERENCES employee ( employee_id )
);

CREATE TABLE claim_net (
    network_id         CHAR(6) NOT NULL,
    accuracy           NUMBER,
    training_duration  INTEGER,
    dataset_id         CHAR(6) NOT NULL,
    CONSTRAINT claim_net_pk PRIMARY KEY ( network_id ),
    CONSTRAINT claim_net_training_dataset_fk 
        FOREIGN KEY ( dataset_id ) REFERENCES training_dataset ( dataset_id )
);

CREATE TABLE insurance_claim (
    claim_id        CHAR(16) NOT NULL,
    username        VARCHAR2(256) NOT NULL,
    cost_of_claim   NUMBER,
    date_submitted  DATE,
    network_id      CHAR(6) NOT NULL,
    CONSTRAINT insurance_claim_pk PRIMARY KEY ( claim_id ),
    CONSTRAINT insurance_claim_claim_net_fk 
        FOREIGN KEY ( network_id ) REFERENCES claim_net ( network_id )
);

CREATE TABLE hardware_request (
    request_id         CHAR(16) NOT NULL,
    date_time          DATE,
    hardware_name      VARCHAR2(1024) NOT NULL,
    hardware_price     NUMBER,
    hardware_shipping  NUMBER,
    employee_id        CHAR(16) NOT NULL,
    vendor_id          CHAR(16) NOT NULL,
    CONSTRAINT hardware_request_pk PRIMARY KEY ( vendor_id, request_id ),
    CONSTRAINT hardware_request_employee_fk 
        FOREIGN KEY ( employee_id ) REFERENCES employee ( employee_id ),
    CONSTRAINT hard_request_hard_vendor_fk 
        FOREIGN KEY ( vendor_id ) REFERENCES hardware_vendor ( vendor_id )
);

CREATE TABLE server (
    server_id        VARCHAR2(256) NOT NULL,
    make             VARCHAR2(256),
    model            VARCHAR2(256),
    specifications   LONG,
    date_to_service  DATE,
    processes        VARCHAR2(256),
    request_id       CHAR(16) NOT NULL, 
    vendor_id        CHAR(16) NOT NULL,
    CONSTRAINT server_pk PRIMARY KEY ( server_id ),
    CONSTRAINT server_hardware_request_fk 
        FOREIGN KEY ( vendor_id, request_id ) REFERENCES hardware_request ( vendor_id, request_id )
);




--Employee Table
INSERT INTO Employee VALUES ('0000000000000001', 'Nicole', 'Hands', TO_DATE('11-22-2009', 'MM-DD-YYYY'), TO_DATE('02-17-1975', 'MM-DD-YYYY'), 1);
INSERT INTO Employee VALUES ('0000000000000002', 'Victor', 'Barlow', TO_DATE('08-04-2010', 'MM-DD-YYYY'), TO_DATE('11-01-1965', 'MM-DD-YYYY'), 4);
INSERT INTO Employee VALUES ('0000000000000003', 'Dawn', 'Laux', TO_DATE('10-20-1994', 'MM-DD-YYYY'), TO_DATE('02-19-1975', 'MM-DD-YYYY'), 9);
INSERT INTO Employee VALUES ('0000000000000004', 'Robert', 'Deadman', TO_DATE('12-10-1999', 'MM-DD-YYYY'), TO_DATE('12-11-2020', 'MM-DD-YYYY'), 6);
INSERT INTO Employee VALUES ('0000000000000005', 'Dominic', 'Kao', TO_DATE('04-02-2001', 'MM-DD-YYYY'), TO_DATE('04-13-1980', 'MM-DD-YYYY'), 9);
INSERT INTO Employee VALUES ('0000000000000006', 'Eric', 'Matson', TO_DATE('10-28-2005', 'MM-DD-YYYY'), TO_DATE('03-04-1969', 'MM-DD-YYYY'), 7);
INSERT INTO Employee VALUES ('0000000000000007', 'Guity', 'Ravai', TO_DATE('11-14-2011', 'MM-DD-YYYY'), TO_DATE('09-07-1965', 'MM-DD-YYYY'), 6);
INSERT INTO Employee VALUES ('0000000000000008', 'Phillip', 'Rawles', TO_DATE('07-10-2019', 'MM-DD-YYYY'), TO_DATE('12-18-1975', 'MM-DD-YYYY'), 3);
INSERT INTO Employee VALUES ('0000000000000009', 'Ida', 'Ngambeki', TO_DATE('04-09-2020', 'MM-DD-YYYY'), TO_DATE('10-14-1975', 'MM-DD-YYYY'), 1);
INSERT INTO Employee VALUES ('0000000000000010', 'Alejandra', 'Magana', TO_DATE('08-13-2017', 'MM-DD-YYYY'), TO_DATE('03-08-1980', 'MM-DD-YYYY'), 8);

--VC Project Table
INSERT INTO VC_Project VALUES ('Hardware-Ordering', NULL, NULL, 'https://github.com/BoilerSolutions/MSAS/projects/1', 'Anything related to Hardware Ordering. This is where issues involving the Hardware Ordering System will be fixed.');
INSERT INTO VC_Project VALUES ('Collocation', 'Nicole Hands', TO_DATE('04-27-2018', 'MM-DD-YYYY'), NULL, 'Anything related to Collocation. This is where problems related to Collocation not working will be fixed.');
INSERT INTO VC_Project VALUES ('Chat', NULL, TO_DATE('11-20-2018', 'MM-DD-YYYY'), 'https://github.com/BoilerSolutions/MSAS/projects/3', 'Anything related to the Chat. This is where new features will be added so users can better communicate.');
INSERT INTO VC_Project VALUES ('Neural-Net', 'Victor Barlow', TO_DATE('07-26-2018', 'MM-DD-YYYY'), 'https://github.com/BoilerSolutions/MSAS/projects/4', 'Anything related to the Neural Net. This is where the Neural Network will be trained and used.');
INSERT INTO VC_Project VALUES ('Server', 'Dawn Laux', TO_DATE('02-02-2016', 'MM-DD-YYYY'), NULL, 'Anything related to the Servers. This could involve specs or status of the servers.');
INSERT INTO VC_Project VALUES ('Frontend', 'Robert Deadman', NULL, 'https://github.com/BoilerSolutions/MSAS/projects/6', 'Anything related to the Frontend of the service. This is where the website development happens.');
INSERT INTO VC_Project VALUES ('Database', 'Dominic Kao', TO_DATE('09-10-2017', 'MM-DD-YYYY'), NULL, 'Anything related to the Database. This could involve adding items to it or doing a new version.');
INSERT INTO VC_Project VALUES ('Support', 'Eric Matson', TO_DATE('08-23-2020', 'MM-DD-YYYY'), NULL, 'Anything related to the Support of users. This is where the support team will interact with customers.');
INSERT INTO VC_Project VALUES ('Version-Control', 'Guity Ravai', TO_DATE('12-18-2019', 'MM-DD-YYYY'), 'https://github.com/BoilerSolutions/MSAS/projects/9', 'Anything related to Version Control. This could be errors or collaboration requests.');
INSERT INTO VC_Project VALUES ('Maintenance', 'Phillip Rawles', TO_DATE('04-02-2015', 'MM-DD-YYYY'), 'https://github.com/BoilerSolutions/MSAS/projects/10', 'Anything related to the Maintenance of the system.');

--VC Branch Table
INSERT INTO VC_Branch VALUES ('master', 'The main branch for Hardware', 'https://github.com/BoilerSolutions/MSAS/tree/Hardware-Ordering/master', 'Hardware-Ordering');
INSERT INTO VC_Branch VALUES ('dev', 'The testing branch for Collocation', 'https://github.com/BoilerSolutions/MSAS/tree/Collocation/dev', 'Collocation');
INSERT INTO VC_Branch VALUES ('fix-hardware-ordering', 'Fixes the bug where someone cannot order hardware', 'https://github.com/BoilerSolutions/MSAS/tree/Hardware-Ordering/fix-hardware-ordering', 'Hardware-Ordering');
INSERT INTO VC_Branch VALUES ('master', 'The main branch for Chat', 'https://github.com/BoilerSolutions/MSAS/tree/Chat/master', 'Chat');
INSERT INTO VC_Branch VALUES ('dev', 'The testing branch for Chat', 'https://github.com/BoilerSolutions/MSAS/tree/Chat/dev', 'Chat');
INSERT INTO VC_Branch VALUES ('make-better-net', 'Constantly develop a better Neural Network', 'https://github.com/BoilerSolutions/MSAS/tree/Neural-Net/make-better-net', 'Neural-Net');
INSERT INTO VC_Branch VALUES ('master', 'The main branch for Collocation', 'https://github.com/BoilerSolutions/MSAS/tree/Collocation/master', 'Collocation');
INSERT INTO VC_Branch VALUES ('master', 'The main branch for the Frontend', 'https://github.com/BoilerSolutions/MSAS/tree/Frontend/master', 'Frontend');
INSERT INTO VC_Branch VALUES ('dev', 'The testing branch for the Frontend', 'https://github.com/BoilerSolutions/MSAS/tree/Frontend/dev', 'Frontend');
INSERT INTO VC_Branch VALUES ('perform-maintenance', 'Maintenance performed on 04/05/2020', 'https://github.com/BoilerSolutions/MSAS/tree/Maintenance/perform-maintenance', 'Maintenance');


--Hardware Vendor Table
insert into Hardware_Vendor values 
('0000000000000001','Hands Hardy Hardware','West Lafayette', 'IN', 'Heavilon Hall','Hands, Nicole','7654547899');
insert into Hardware_Vendor values 
('0000000000000002','JJ Tools Inc','Kansas City', 'MO', '3321 Bald Street','Jackson, James','5436667890');
insert into Hardware_Vendor values 
('0000000000000003','Hammers Deluxe','Tucson', 'AZ', '4563 Hammer Rd','Claw, Bob','5363990367');
insert into Hardware_Vendor values 
('0000000000000004','Knock on Wood','Modesto', 'CA', '43 Wood Blvd','Tree, Jeff','2376548232');
insert into Hardware_Vendor values 
('0000000000000005','Tools For You','Hialeah', 'FL', '123 Plain Rd','Ross, Bob','3589993456');
insert into Hardware_Vendor values 
('0000000000000006','Lumber Co','Boston', 'MA', '8657 Log Drive','Lumber, Jack','9992765543');
insert into Hardware_Vendor values 
('0000000000000007','Drill It','Scottsdale', 'AZ', 'Rubble Road','Gravel, Tom','5763268754');
insert into Hardware_Vendor values 
('0000000000000008','Bills Hard Wood','Orlando', 'FL', '656 Rod Street','Long, Steve','5684665458');
insert into Hardware_Vendor values 
('0000000000000009','Drill Everything','Cleveland', 'OH', '3321 Rocky Road','Buzz, George','5678907656');
insert into Hardware_Vendor values 
('0000000000000010','Hello Decks','Tampa', 'FL', '2222 Riverside Lane','Bud, Jack','8765778900');

--Hardware Request Table
insert into Hardware_Request values
('0000000000000001',to_date('10-12-2019', 'MM-DD-YYYY'),'Box of Nails','10','4','0000000000000005','0000000000000008');
insert into Hardware_Request values
('0000000000000002',to_date('11-24-2019', 'MM-DD-YYYY'),'Screws','8','2','0000000000000006','0000000000000009');
insert into Hardware_Request values
('0000000000000003',to_date('05-13-2019', 'MM-DD-YYYY'),'2x4 Wood','20','8','0000000000000007','0000000000000010');
insert into Hardware_Request values
('0000000000000004',to_date('01-28-2019', 'MM-DD-YYYY'),'Custom Wood Frame','25','10','0000000000000008','0000000000000007');
insert into Hardware_Request values
('0000000000000005',to_date('10-13-2019', 'MM-DD-YYYY'),'Hammer','16','8','0000000000000009','0000000000000006');
insert into Hardware_Request values
('0000000000000006',to_date('08-16-2019', 'MM-DD-YYYY'),'Drill','7','5','0000000000000010','0000000000000005');
insert into Hardware_Request values
('0000000000000007',to_date('10-22-2019', 'MM-DD-YYYY'),'Metal Hinge','50','33','0000000000000004','0000000000000004');
insert into Hardware_Request values
('0000000000000008',to_date('03-08-2019', 'MM-DD-YYYY'),'Bolts','77','20','0000000000000003','0000000000000003');
insert into Hardware_Request values
('0000000000000009',to_date('11-05-2019', 'MM-DD-YYYY'),'Plywood Crate','8','6','0000000000000002','0000000000000002');
insert into Hardware_Request values
('0000000000000010',to_date('06-12-2019', 'MM-DD-YYYY'),'Nailgun','11','4','0000000000000001','0000000000000001');

--Server Table
insert into server values
('10','HP','M160','Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink',to_date('12-22-2016', 'MM-DD-YYYY'),'Intl,Runtime,Xp','0000000000000007','0000000000000004');
insert into server values
('20','Dell','M170','Intel Xeon E5-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink',to_date('11-12-2019', 'MM-DD-YYYY'),'Intl,Mgmt,Runtime,Xp','0000000000000008','0000000000000003');
insert into server values
('30','Cisco','M260','Intel Xeon E1-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink',to_date('12-23-2016', 'MM-DD-YYYY'),'Intl,Mgmt,Runtime,Xp','0000000000000009','0000000000000002');
insert into server values
('40','Microsoft','M1990','Intel Xeon E2-2635 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink',to_date('05-21-2018', 'MM-DD-YYYY'),'Intl,Mgmt,Runtime,Xp','0000000000000010','0000000000000001');
insert into server values
('50','Dell','M170','Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink',to_date('02-12-2016', 'MM-DD-YYYY'),'Intl,Mgmt,Runtime','0000000000000006','0000000000000005');
insert into server values
('60','Dell','M160','Intel Xeon E5-2650 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink',to_date('08-22-2017', 'MM-DD-YYYY'),'Intl,Mgmt,Runtime,Xp','0000000000000005','0000000000000006');
insert into server values
('70','HP','M190','Intel Xeon E2-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink',to_date('12-02-2016', 'MM-DD-YYYY'),'Intl,Mgmt,Runtime,Xp','0000000000000004','0000000000000007');
insert into server values
('80','HP','M130','Intel Xeon E4-3630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink',to_date('12-12-2017', 'MM-DD-YYYY'),'Intl,Mgmt,Runtime,Xp','0000000000000003','0000000000000010');
insert into server values
('90','Microsoft','M360','Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink',to_date('12-22-2017', 'MM-DD-YYYY'),'Intl,Mgmt,Xp','0000000000000002','0000000000000009');
insert into server values
('100','HP','M250','Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink',to_date('11-02-2016', 'MM-DD-YYYY'),'Mgmt,Runtime,Xp','0000000000000001','0000000000000008');

--Chat Room Table
INSERT INTO chat_room VALUES ('Development Channel', 3, (TO_DATE('03-10-2020', 'MM-DD-YYYY')));
INSERT INTO chat_room VALUES ('General', 1, (TO_DATE('03-10-2020', 'MM-DD-YYYY')));
INSERT INTO chat_room VALUES ('Admin', 5, (TO_DATE('03-10-2020', 'MM-DD-YYYY')));
INSERT INTO chat_room VALUES ('Executive', 5, (TO_DATE('03-10-2020', 'MM-DD-YYYY')));
INSERT INTO chat_room VALUES ('IT', 3, (TO_DATE('03-10-2020', 'MM-DD-YYYY')));
INSERT INTO chat_room VALUES ('Bug Reports', 1, (TO_DATE('03-10-2020', 'MM-DD-YYYY')));
INSERT INTO chat_room VALUES ('Announcements', 1, (TO_DATE('03-10-2020', 'MM-DD-YYYY')));
INSERT INTO chat_room VALUES ('System Requests', 2, (TO_DATE('03-10-2020', 'MM-DD-YYYY')));
INSERT INTO chat_room VALUES ('Off Topic', 1, (TO_DATE('03-10-2020', 'MM-DD-YYYY')));
INSERT INTO chat_room VALUES ('Management', 3, (TO_DATE('03-10-2020', 'MM-DD-YYYY')));

--Chat Message Table
INSERT INTO chat_message VALUES (TO_DATE('03-25-2020 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), '0000000000000001', 'This is a test message', 'Development Channel');
INSERT INTO chat_message VALUES (TO_DATE('03-25-2020 15:02:25', 'MM-DD-YYYY HH24:MI:SS'), '0000000000000002', 'Did you get the chat system working?', 'Development Channel');
INSERT INTO chat_message VALUES (TO_DATE('03-25-2020 15:03:42', 'MM-DD-YYYY HH24:MI:SS'), '0000000000000001', 'Looks like it. Probably have to do more testing', 'Development Channel');
INSERT INTO chat_message VALUES (TO_DATE('03-25-2020 15:04:44', 'MM-DD-YYYY HH24:MI:SS'), '0000000000000002', ':thumbsup:', 'Development Channel');
INSERT INTO chat_message VALUES (TO_DATE('03-26-2020 15:00:12', 'MM-DD-YYYY HH24:MI:SS'), '0000000000000001', 'Day two of testing, seems to work fine', 'Development Channel');
INSERT INTO chat_message VALUES (TO_DATE('03-26-2020 15:00:24', 'MM_DD-YYYY HH24:MI:SS'), '0000000000000001', 'Can someone else try sending a message?', 'Development Channel');
INSERT INTO chat_message VALUES (TO_DATE('03-26-2020 15:01:55', 'MM-DD-YYYY HH24:MI:SS'), '0000000000000003', 'Yo', 'Development Channel');
INSERT INTO chat_message VALUES (TO_DATE('03-26-2020 15:02:01', 'MM-DD-YYYY HH24:MI:SS'), '0000000000000001', 'Thanks', 'Development Channel');
INSERT INTO chat_message VALUES (TO_DATE('03-27-2020 15:00:21', 'MM-DD-YYYY HH24:MI:SS'), '0000000000000005', 'Anyone down for lunch today? Thinking pizza', 'General');
INSERT INTO chat_message VALUES (TO_DATE('03-27-2020 15:00:35', 'MM-DD-YYYY HH24:MI:SS'), '0000000000000007', 'Lets do it', 'General');
INSERT INTO chat_message VALUES (TO_DATE('03-27-2020 15:00:59', 'MM-DD-YYYY HH24:MI:SS'), '0000000000000007', 'Check out general chat, lunch today if anyone wants it', 'Admin');

--Training Dataset Table
insert into training_dataset values ('DS-001',to_date('03-11-2019', 'MM-DD-YYYY'), '\\MEDICS\ClaimNet\Datasets\DS-001\', '0000000000000001');
insert into training_dataset values ('DS-002',to_date('03-12-2019', 'MM-DD-YYYY'), '\\MEDICS\ClaimNet\Datasets\DS-002\', '0000000000000002');
insert into training_dataset values ('DS-003',to_date('03-13-2019', 'MM-DD-YYYY'), '\\MEDICS\ClaimNet\Datasets\DS-003\', '0000000000000003');
insert into training_dataset values ('DS-004',to_date('03-14-2019', 'MM-DD-YYYY'), '\\MEDICS\ClaimNet\Datasets\DS-004\', '0000000000000004');
insert into training_dataset values ('DS-005',to_date('03-15-2019', 'MM-DD-YYYY'), '\\MEDICS\ClaimNet\Datasets\DS-005\', '0000000000000005');
insert into training_dataset values ('DS-006',to_date('03-16-2019', 'MM-DD-YYYY'), '\\MEDICS\ClaimNet\Datasets\DS-006\', '0000000000000006');
insert into training_dataset values ('DS-007',to_date('03-17-2019', 'MM-DD-YYYY'), '\\MEDICS\ClaimNet\Datasets\DS-007\', '0000000000000007');
insert into training_dataset values ('DS-008',to_date('03-18-2019', 'MM-DD-YYYY'), '\\MEDICS\ClaimNet\Datasets\DS-008\', '0000000000000008');
insert into training_dataset values ('DS-009',to_date('03-19-2019', 'MM-DD-YYYY'), '\\MEDICS\ClaimNet\Datasets\DS-009\', '0000000000000009');
insert into training_dataset values ('DS-010',to_date('03-20-2019', 'MM-DD-YYYY'), '\\MEDICS\ClaimNet\Datasets\DS-010\', '0000000000000010');

--Claim Network Table
insert into claim_net values ('CN-001', .34, 654, 'DS-001');
insert into claim_net values ('CN-002', .76, 766, 'DS-002');
insert into claim_net values ('CN-003', .74, 543, 'DS-003');
insert into claim_net values ('CN-004', .54, 621, 'DS-004');
insert into claim_net values ('CN-005', .62, 754, 'DS-005');
insert into claim_net values ('CN-006', .89, 641, 'DS-006');
insert into claim_net values ('CN-007', .12, 788, 'DS-007');
insert into claim_net values ('CN-008', .54, 976, 'DS-008');
insert into claim_net values ('CN-009', .78, 765, 'DS-009');
insert into claim_net values ('CN-010', .83, 788, 'DS-010');

--Insurance Claim table
insert into insurance_claim values ('0000000000000001', 'dgfs322', 2800, to_date('03-01-2019', 'MM-DD-YYYY'), 'CN-001');
insert into insurance_claim values ('0000000000000002', 'ndkd347', 3445, to_date('03-02-2019', 'MM-DD-YYYY'), 'CN-002');
insert into insurance_claim values ('0000000000000003', 'ndfj564', 6550, to_date('03-03-2019', 'MM-DD-YYYY'), 'CN-003');
insert into insurance_claim values ('0000000000000004', 'dgfm234', 603, to_date('03-04-2019', 'MM-DD-YYYY'), 'CN-004');
insert into insurance_claim values ('0000000000000005', 'mbfk256', 467, to_date('03-05-2019', 'MM-DD-YYYY'), 'CN-005');
insert into insurance_claim values ('0000000000000006', 'nbvg345', 230, to_date('03-06-2019', 'MM-DD-YYYY'), 'CN-006');
insert into insurance_claim values ('0000000000000007', 'hjjh235', 340, to_date('03-07-2019', 'MM-DD-YYYY'), 'CN-007');
insert into insurance_claim values ('0000000000000008', 'hjgj357', 371, to_date('03-08-2019', 'MM-DD-YYYY'), 'CN-008');
insert into insurance_claim values ('0000000000000009', 'mjfd356', 3250, to_date('03-09-2019', 'MM-DD-YYYY'), 'CN-009');
insert into insurance_claim values ('0000000000000010', 'zcgf954', 5270, to_date('03-10-2019', 'MM-DD-YYYY'), 'CN-010');

--VC Commit Table
insert into vc_commit values ('8237594878982345', 'master', 'Medical Insurance', TO_DATE('03-25-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), 'Test source code', 'Test Files', 'Test Reeason', '0000000000000001', 'Hardware-Ordering');
insert into vc_commit values ('3838484857575656', 'dev', 'Medical Insurance', TO_DATE('03-25-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), 'Test source code', 'Test Files', 'Test Reeason', '0000000000000002', 'Collocation');
insert into vc_commit values ('1010292938384747', 'fix-hardware-ordering', 'Medical Insurance', TO_DATE('03-25-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), 'Test source code', 'Test Files', 'Test Reeason', '0000000000000003', 'Hardware-Ordering');
insert into vc_commit values ('2929383829291010', 'master', 'Medical Insurance', TO_DATE('03-25-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), 'Test source code', 'Test Files', 'Test Reeason', '0000000000000004', 'Chat');
insert into vc_commit values ('2929383832929101', 'dev', 'Medical Insurance', TO_DATE('03-25-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), 'Test source code', 'Test Files', 'Test Reeason', '0000000000000005', 'Chat');
insert into vc_commit values ('9090878776766565', 'make-better-net', 'Medical Insurance', TO_DATE('03-25-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), 'Test source code', 'Test Files', 'Test Reeason', '0000000000000006', 'Neural-Net');
insert into vc_commit values ('2929383817172626', 'master', 'Medical Insurance', TO_DATE('03-25-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), 'Test source code', 'Test Files', 'Test Reeason', '0000000000000007', 'Collocation');
insert into vc_commit values ('9898767665654747', 'master', 'Medical Insurance', TO_DATE('03-25-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), 'Test source code', 'Test Files', 'Test Reeason', '0000000000000008', 'Frontend');
insert into vc_commit values ('2929383857576060', 'dev', 'Medical Insurance', TO_DATE('03-25-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), 'Test source code', 'Test Files', 'Test Reeason', '0000000000000009', 'Frontend');
insert into vc_commit values ('2929383847475959', 'perform-maintenance', 'Medical Insurance', TO_DATE('03-25-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), 'Test source code', 'Test Files', 'Test Reeason', '0000000000000010', 'Maintenance');

--VC Issues Table
insert into vc_issue values ('2939483849492828', 'Moe','8282','1','Fever','Kelly', 'Hardware-Ordering', 'master');
insert into vc_issue values ('1828494928283737', 'Moe','2423','1','Fever','Hn', 'Collocation', 'dev');
insert into vc_issue values ('1010292928282828', 'Moe','2534','1','Fever','JKJK', 'Hardware-Ordering', 'fix-hardware-ordering');
insert into vc_issue values ('1919191919191919', 'Moe','3424','1','Fever','THODH', 'Chat', 'master');
insert into vc_issue values ('2828282828282828', 'Moe','7575','1','Fever','KOHN', 'Chat', 'dev');
insert into vc_issue values ('3737373737373737', 'Moe','8989','1','Fever','Marco', 'Neural-Net', 'make-better-net');
insert into vc_issue values ('4747474747474747', 'Moe','1212','1','Fever','Polo', 'Collocation', 'master');
insert into vc_issue values ('5757575757575757', 'Moe','2323','1','Fever','Rahul', 'Frontend', 'master');
insert into vc_issue values ('6767676767676767', 'Moe','3434','1','Fever','Koi', 'Frontend', 'dev');
insert into vc_issue values ('7777777777777777', 'Moe','4545','1','Fever','Thul', 'Maintenance', 'perform-maintenance');

--Support Ticket
insert into support_ticket values ('2929373749491818','Hulk', TO_DATE('07-19-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), '1919', 'Timmy', '0000000000000001','Hardware-Ordering','master','2939483849492828'); 
insert into support_ticket values ('1515151515151515','Hulk', TO_DATE('07-19-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), '1919', 'Timmy', '0000000000000002','Collocation','dev','1828494928283737'); 
insert into support_ticket values ('2525252525252522','Hulk', TO_DATE('07-19-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), '1919', 'Timmy', '0000000000000003','Hardware-Ordering','fix-hardware-ordering','1010292928282828'); 
insert into support_ticket values ('3636363636363636','Hulk', TO_DATE('07-19-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), '1919', 'Timmy', '0000000000000004','Chat','master','1919191919191919'); 
insert into support_ticket values ('4646464646464646','Hulk', TO_DATE('07-19-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), '1919', 'Timmy', '0000000000000005','Chat','dev','2828282828282828'); 
insert into support_ticket values ('5656565656565656','Hulk', TO_DATE('07-19-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), '1919', 'Timmy', '0000000000000006','Neural-Net','make-better-net','3737373737373737'); 
insert into support_ticket values ('1010101010101010','Hulk', TO_DATE('07-19-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), '1919', 'Timmy', '0000000000000007','Collocation','master','4747474747474747'); 
insert into support_ticket values ('1919191919191919','Hulk', TO_DATE('07-19-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), '1919', 'Timmy', '0000000000000008','Frontend','master','5757575757575757'); 
insert into support_ticket values ('2828282828282828','Hulk', TO_DATE('07-19-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), '1919', 'Timmy', '0000000000000009','Frontend','dev','6767676767676767'); 
insert into support_ticket values ('3838383838383838','Hulk', TO_DATE('07-19-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), '1919', 'Timmy', '0000000000000010','Maintenance','perform-maintenance','7777777777777777'); 