DROP TABLE CHAT_MESSAGE     CASCADE CONSTRAINTS;
DROP TABLE CHAT_ROOM        CASCADE CONSTRAINTS;
DROP TABLE CLAIM_NET        CASCADE CONSTRAINTS;
DROP TABLE EMPLOYEE         CASCADE CONSTRAINTS;
DROP TABLE HARDWARE_REQUEST CASCADE CONSTRAINTS;
DROP TABLE HARDWARE_VENDOR  CASCADE CONSTRAINTS;
DROP TABLE INSURANCE_CLAIM  CASCADE CONSTRAINTS;
DROP TABLE SERVER           CASCADE CONSTRAINTS;
DROP TABLE SUPPORT_TICKET   CASCADE CONSTRAINTS;
DROP TABLE TRAINING_DATASET CASCADE CONSTRAINTS;
DROP TABLE VC_BRANCH        CASCADE CONSTRAINTS;
DROP TABLE VC_COMMIT        CASCADE CONSTRAINTS;
DROP TABLE VC_ISSUE         CASCADE CONSTRAINTS;
DROP TABLE VC_PROJECT       CASCADE CONSTRAINTS;

CREATE TABLE employee (
    employee_id             CHAR(16) NOT NULL,
    first_name              VARCHAR2(256),
    last_name               VARCHAR2(256),
    hire_date               DATE,
    birth_date              DATE,
    permitted_access_level  INTEGER,
    CONSTRAINT employee_pk PRIMARY KEY ( employee_id )
);

CREATE TABLE vc_project (
    project_name   VARCHAR2(256) NOT NULL,
    creator        VARCHAR2(256),
    creation_date  DATE,
    url            VARCHAR2(512),
    description    LONG,
    CONSTRAINT vc_project_pk PRIMARY KEY ( project_name )
);

CREATE TABLE vc_branch (
    branch_name   VARCHAR2(256) NOT NULL,
    description   LONG,
    url           VARCHAR2(256),
    project_name  VARCHAR2(256) NOT NULL,
    CONSTRAINT vc_branch_pk PRIMARY KEY ( project_name, branch_name ),
    CONSTRAINT vc_branch_vc_project_fk 
        FOREIGN KEY ( project_name ) REFERENCES vc_project ( project_name )
);

CREATE TABLE vc_commit (
    commit_id      CHAR(16) NOT NULL,
    branch_name    VARCHAR2(256) NOT NULL,
    description    VARCHAR2(1024),
    date_time      DATE,
    source_code    VARCHAR2(1024),
    files_changed  VARCHAR2(1024),
    change_reason  VARCHAR2(1024),
    employee_id    CHAR(16) NOT NULL,
    project_name   VARCHAR2(256) NOT NULL,
    CONSTRAINT vc_commit_pk PRIMARY KEY ( commit_id ),
    CONSTRAINT vc_commit_employee_fk 
        FOREIGN KEY ( employee_id ) REFERENCES employee ( employee_id ),
    CONSTRAINT vc_commit_vc_branch_fk 
        FOREIGN KEY ( project_name, branch_name ) REFERENCES vc_branch ( project_name, branch_name )
);

CREATE TABLE vc_issue (
    issue_id      CHAR(16) NOT NULL,
    submitter     VARCHAR2(256) NOT NULL,
    description   LONG,
    severity      INTEGER,
    category      VARCHAR2(32),
    assignee      VARCHAR2(256),
    project_name  VARCHAR2(256) NOT NULL,
    branch_name   VARCHAR2(256) NOT NULL,
    CONSTRAINT vc_issue_pk PRIMARY KEY ( issue_id ),
    CONSTRAINT vc_issue_vc_branch_fk 
        FOREIGN KEY ( project_name, branch_name ) REFERENCES vc_branch ( project_name, branch_name )
);

CREATE TABLE support_ticket (
    ticket_id            CHAR(16) NOT NULL,
    submitted_by         VARCHAR2(256),
    date_time_submitted  DATE,
    description          LONG,
    assignee             VARCHAR2(256),
    employee_id          CHAR(16) NOT NULL,  
    project_name         VARCHAR2(256) NOT NULL,
    branch_name          VARCHAR2(256) NOT NULL,
    issue_id             CHAR(16) NOT NULL,
    CONSTRAINT support_ticket_pk PRIMARY KEY ( ticket_id ),
    CONSTRAINT support_ticket_employee_fk 
        FOREIGN KEY ( employee_id ) REFERENCES employee ( employee_id ),
    CONSTRAINT support_ticket_vc_issue_fk 
        FOREIGN KEY ( issue_id ) REFERENCES vc_issue ( issue_id )
);

CREATE TABLE hardware_vendor (
    vendor_id       CHAR(16) NOT NULL,
    name            VARCHAR2(256),
    city            VARCHAR2(256),
    state_province  VARCHAR2(256),
    street_address  VARCHAR2(256),
    contact_name    VARCHAR2(256),
    phone           CHAR(11),
    CONSTRAINT hardware_vendor_pk PRIMARY KEY ( vendor_id )
);

CREATE TABLE chat_room (
    chat_room_name  VARCHAR2(128) NOT NULL,
    access_level    INTEGER,
    creation_date   DATE,
    CONSTRAINT chat_room_pk PRIMARY KEY ( chat_room_name )
);

CREATE TABLE chat_message (
    date_time         DATE NOT NULL,
    employee_id       CHAR(16) NOT NULL,
    message_contents  LONG NOT NULL,
    chat_room_name    VARCHAR2(128) NOT NULL,
    CONSTRAINT chat_message_pk PRIMARY KEY ( employee_id, date_time ),
    CONSTRAINT chat_message_chat_room_fk 
        FOREIGN KEY ( chat_room_name ) REFERENCES chat_room ( chat_room_name ),
    CONSTRAINT chat_message_employee_fk 
        FOREIGN KEY ( employee_id ) REFERENCES employee ( employee_id )
);

CREATE TABLE training_dataset (
    dataset_id      CHAR(6) NOT NULL,
    date_time       DATE,
    data_directory  VARCHAR2(256),
    employee_id     CHAR(16) NOT NULL,
    CONSTRAINT training_dataset_pk PRIMARY KEY ( dataset_id ),
    CONSTRAINT training_dataset_employee_fk 
        FOREIGN KEY ( employee_id ) REFERENCES employee ( employee_id )
);

CREATE TABLE claim_net (
    network_id         CHAR(6) NOT NULL,
    accuracy           NUMBER,
    training_duration  INTEGER,
    dataset_id         CHAR(6) NOT NULL,
    CONSTRAINT claim_net_pk PRIMARY KEY ( network_id ),
    CONSTRAINT claim_net_training_dataset_fk 
        FOREIGN KEY ( dataset_id ) REFERENCES training_dataset ( dataset_id )
);

CREATE TABLE insurance_claim (
    claim_id        CHAR(16) NOT NULL,
    username        VARCHAR2(256) NOT NULL,
    cost_of_claim   NUMBER,
    date_submitted  DATE,
    network_id      CHAR(16) NOT NULL,
    CONSTRAINT insurance_claim_pk PRIMARY KEY ( claim_id ),
    CONSTRAINT insurance_claim_claim_net_fk 
        FOREIGN KEY ( network_id ) REFERENCES claim_net ( network_id )
);

CREATE TABLE hardware_request (
    request_id         CHAR(16) NOT NULL,
    date_time          DATE,
    hardware_name      VARCHAR2(1024) NOT NULL,
    hardware_price     NUMBER,
    hardware_shipping  NUMBER,
    employee_id        CHAR(16) NOT NULL,
    vendor_id          CHAR(16) NOT NULL,
    CONSTRAINT hardware_request_pk PRIMARY KEY ( vendor_id, request_id ),
    CONSTRAINT hardware_request_employee_fk 
        FOREIGN KEY ( employee_id ) REFERENCES employee ( employee_id ),
    CONSTRAINT hard_request_hard_vendor_fk 
        FOREIGN KEY ( vendor_id ) REFERENCES hardware_vendor ( vendor_id )
);

CREATE TABLE server (
    server_id        VARCHAR2(256) NOT NULL,
    make             VARCHAR2(256),
    model            VARCHAR2(256),
    specifications   LONG,
    date_to_service  DATE,
    processes        VARCHAR2(256),
    request_id       CHAR(16) NOT NULL, 
    vendor_id        CHAR(16) NOT NULL,
    CONSTRAINT server_pk PRIMARY KEY ( server_id ),
    CONSTRAINT server_hardware_request_fk 
        FOREIGN KEY ( vendor_id, request_id ) REFERENCES hardware_request ( vendor_id, request_id )
);

--Employee Table
INSERT INTO Employee VALUES ('0000000000000001', 'Nicole', 'Hands', TO_DATE('11-22-2009', 'MM-DD-YYYY'), TO_DATE('02-17-1975', 'MM-DD-YYYY'), 1);
INSERT INTO Employee VALUES ('0000000000000002', 'Victor', 'Barlow', TO_DATE('08-04-2010', 'MM-DD-YYYY'), TO_DATE('11-01-1965', 'MM-DD-YYYY'), 4);
INSERT INTO Employee VALUES ('0000000000000003', 'Dawn', 'Laux', TO_DATE('10-20-1994', 'MM-DD-YYYY'), TO_DATE('02-19-1975', 'MM-DD-YYYY'), 9);
INSERT INTO Employee VALUES ('0000000000000004', 'Robert', 'Deadman', TO_DATE('12-10-1999', 'MM-DD-YYYY'), TO_DATE('12-11-2020', 'MM-DD-YYYY'), 6);
INSERT INTO Employee VALUES ('0000000000000005', 'Dominic', 'Kao', TO_DATE('04-02-2001', 'MM-DD-YYYY'), TO_DATE('04-13-1980', 'MM-DD-YYYY'), 9);
INSERT INTO Employee VALUES ('0000000000000006', 'Eric', 'Matson', TO_DATE('10-28-2005', 'MM-DD-YYYY'), TO_DATE('03-04-1969', 'MM-DD-YYYY'), 7);
INSERT INTO Employee VALUES ('0000000000000007', 'Guity', 'Ravai', TO_DATE('11-14-2011', 'MM-DD-YYYY'), TO_DATE('09-07-1965', 'MM-DD-YYYY'), 6);
INSERT INTO Employee VALUES ('0000000000000008', 'Phillip', 'Rawles', TO_DATE('07-10-2019', 'MM-DD-YYYY'), TO_DATE('12-18-1975', 'MM-DD-YYYY'), 3);
INSERT INTO Employee VALUES ('0000000000000009', 'Ida', 'Ngambeki', TO_DATE('04-09-2020', 'MM-DD-YYYY'), TO_DATE('10-14-1975', 'MM-DD-YYYY'), 1);
INSERT INTO Employee VALUES ('0000000000000010', 'Alejandra', 'Magana', TO_DATE('08-13-2017', 'MM-DD-YYYY'), TO_DATE('03-08-1980', 'MM-DD-YYYY'), 8);

--VC Project Table
INSERT INTO VC_Project VALUES ('Hardware-Ordering', NULL, NULL, 'https://github.com/BoilerSolutions/MSAS/projects/1', 'Anything related to Hardware Ordering. This is where issues involving the Hardware Ordering System will be fixed.');
INSERT INTO VC_Project VALUES ('Collocation', 'Nicole Hands', TO_DATE('04-27-2018', 'MM-DD-YYYY'), NULL, 'Anything related to Collocation. This is where problems related to Collocation not working will be fixed.');
INSERT INTO VC_Project VALUES ('Chat', NULL, TO_DATE('11-20-2018', 'MM-DD-YYYY'), 'https://github.com/BoilerSolutions/MSAS/projects/3', 'Anything related to the Chat. This is where new features will be added so users can better communicate.');
INSERT INTO VC_Project VALUES ('Neural-Net', 'Victor Barlow', TO_DATE('07-26-2018', 'MM-DD-YYYY'), 'https://github.com/BoilerSolutions/MSAS/projects/4', 'Anything related to the Neural Net. This is where the Neural Network will be trained and used.');
INSERT INTO VC_Project VALUES ('Server', 'Dawn Laux', TO_DATE('02-02-2016', 'MM-DD-YYYY'), NULL, 'Anything related to the Servers. This could involve specs or status of the servers.');
INSERT INTO VC_Project VALUES ('Frontend', 'Robert Deadman', NULL, 'https://github.com/BoilerSolutions/MSAS/projects/6', 'Anything related to the Frontend of the service. This is where the website development happens.');
INSERT INTO VC_Project VALUES ('Database', 'Dominic Kao', TO_DATE('09-10-2017', 'MM-DD-YYYY'), NULL, 'Anything related to the Database. This could involve adding items to it or doing a new version.');
INSERT INTO VC_Project VALUES ('Support', 'Eric Matson', TO_DATE('08-23-2020', 'MM-DD-YYYY'), NULL, 'Anything related to the Support of users. This is where the support team will interact with customers.');
INSERT INTO VC_Project VALUES ('Version-Control', 'Guity Ravai', TO_DATE('12-18-2019', 'MM-DD-YYYY'), 'https://github.com/BoilerSolutions/MSAS/projects/9', 'Anything related to Version Control. This could be errors or collaboration requests.');
INSERT INTO VC_Project VALUES ('Maintenance', 'Phillip Rawles', TO_DATE('04-02-2015', 'MM-DD-YYYY'), 'https://github.com/BoilerSolutions/MSAS/projects/10', 'Anything related to the Maintenance of the system.');

--VC Branch Table
INSERT INTO VC_Branch VALUES ('master', 'The main branch for Hardware', 'https://github.com/BoilerSolutions/MSAS/tree/Hardware-Ordering/master', 'Hardware-Ordering');
INSERT INTO VC_Branch VALUES ('dev', 'The testing branch for Collocation', 'https://github.com/BoilerSolutions/MSAS/tree/Collocation/dev', 'Collocation');
INSERT INTO VC_Branch VALUES ('fix-hardware-ordering', 'Fixes the bug where someone cannot order hardware', 'https://github.com/BoilerSolutions/MSAS/tree/Hardware-Ordering/fix-hardware-ordering', 'Hardware-Ordering');
INSERT INTO VC_Branch VALUES ('master', 'The main branch for Chat', 'https://github.com/BoilerSolutions/MSAS/tree/Chat/master', 'Chat');
INSERT INTO VC_Branch VALUES ('dev', 'The testing branch for Chat', 'https://github.com/BoilerSolutions/MSAS/tree/Chat/dev', 'Chat');
INSERT INTO VC_Branch VALUES ('make-better-net', 'Constantly develop a better Neural Network', 'https://github.com/BoilerSolutions/MSAS/tree/Neural-Net/make-better-net', 'Neural-Net');
INSERT INTO VC_Branch VALUES ('master', 'The main branch for Collocation', 'https://github.com/BoilerSolutions/MSAS/tree/Collocation/master', 'Collocation');
INSERT INTO VC_Branch VALUES ('master', 'The main branch for the Frontend', 'https://github.com/BoilerSolutions/MSAS/tree/Frontend/master', 'Frontend');
INSERT INTO VC_Branch VALUES ('dev', 'The testing branch for the Frontend', 'https://github.com/BoilerSolutions/MSAS/tree/Frontend/dev', 'Frontend');
INSERT INTO VC_Branch VALUES ('perform-maintenance', 'Maintenance performed on 04/05/2020', 'https://github.com/BoilerSolutions/MSAS/tree/Maintenance/perform-maintenance', 'Maintenance');