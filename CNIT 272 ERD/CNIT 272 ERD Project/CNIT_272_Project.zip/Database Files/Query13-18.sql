/* 13.
*/
select vc_branch.description, vc_project.project_name
from vc_branch
inner join vc_project
on vc_branch.project_name = vc_project.project_name
where vc_branch.project_name = 'Chat' OR vc_branch.project_name = 'Frontend';
/*
Result:

DESCRIPTION                                                                      PROJECT_NAME                                                                                                                                                                                                                                                    
-------------------------------------------------------------------------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
The testing branch for Chat                                                      Chat                                                                                                                                                                                                                                                            
The main branch for Chat                                                         Chat                                                                                                                                                                                                                                                            
The testing branch for the Frontend                                              Frontend                                                                                                                                                                                                                                                        
The main branch for the Frontend                                                 Frontend                                                                                                                                                                                                                                                        
*/

/* 14.
*/
COL FIRST_NAME FORMAT a15;
COL LAST_NAME FORMAT a15;
COL ORDER_DATE FORMAT a35;

SELECT HARDWARE_REQUEST.REQUEST_ID, TO_CHAR(HARDWARE_REQUEST.DATE_TIME, 'fmMonth DD, YYYY, Day') AS ORDER_DATE, HARDWARE_REQUEST.EMPLOYEE_ID, EMPLOYEE.FIRST_NAME, EMPLOYEE.LAST_NAME
FROM HARDWARE_REQUEST INNER JOIN EMPLOYEE ON HARDWARE_REQUEST.EMPLOYEE_ID = EMPLOYEE.EMPLOYEE_ID
                      INNER JOIN HARDWARE_VENDOR ON HARDWARE_REQUEST.VENDOR_ID = HARDWARE_VENDOR.VENDOR_ID
                      INNER JOIN SERVER ON HARDWARE_REQUEST.REQUEST_ID = SERVER.REQUEST_ID;

/*
Result:
REQUEST_ID       ORDER_DATE                          EMPLOYEE_ID      FIRST_NAME      LAST_NAME      
---------------- ----------------------------------- ---------------- --------------- ---------------
0000000000000007 October 22, 2019, Tuesday           0000000000000004 Robert          Deadman        
0000000000000008 March 8, 2019, Friday               0000000000000003 Dawn            Laux           
0000000000000009 November 5, 2019, Tuesday           0000000000000002 Victor          Barlow         
0000000000000010 June 12, 2019, Wednesday            0000000000000001 Nicole          Hands          
0000000000000006 August 16, 2019, Friday             0000000000000010 Alejandra       Magana         
0000000000000005 October 13, 2019, Sunday            0000000000000009 Ida             Ngambeki       
0000000000000004 January 28, 2019, Monday            0000000000000008 Phillip         Rawles         
0000000000000003 May 13, 2019, Monday                0000000000000007 Guity           Ravai          
0000000000000002 November 24, 2019, Sunday           0000000000000006 Eric            Matson         
0000000000000001 October 12, 2019, Saturday          0000000000000005 Dominic         Kao            

10 rows selected. 
*/   
/* 15.
*/
select project_name, description
from vc_branch
where project_name NOT IN (select project_name from vc_project where project_name = 'Collocation')
;

/*
Result:
PROJECT_NAME                                                                                                                                                                                                                                                     DESCRIPTION                                                                     
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- --------------------------------------------------------------------------------
Hardware-Ordering                                                                                                                                                                                                                                                The main branch for Hardware                                                    
Hardware-Ordering                                                                                                                                                                                                                                                Fixes the bug where someone cannot order hardware                               
Chat                                                                                                                                                                                                                                                             The main branch for Chat                                                        
Chat                                                                                                                                                                                                                                                             The testing branch for Chat                                                     
Neural-Net                                                                                                                                                                                                                                                       Constantly develop a better Neural Network                                      
Frontend                                                                                                                                                                                                                                                         The main branch for the Frontend                                                
Frontend                                                                                                                                                                                                                                                         The testing branch for the Frontend                                             
Maintenance                                                                                                                                                                                                                                                      Maintenance performed on 04/05/2020                                             

8 rows selected. 
*/

/* 16.
*/
select AVG(access_level)
from chat_room
where access_level IN (select MAX(access_level) from chat_room);
/*
Result:
AVG(ACCESS_LEVEL)
-----------------
                5
*/

/* 17.
*/
select AVG(access_level), chat_message.chat_room_name
from chat_room
inner join chat_message on chat_room.chat_room_name = chat_message.chat_room_name
group by chat_message.chat_room_name;
/*
Result:
AVG(ACCESS_LEVEL) CHAT_ROOM_NAME                                                                                                                  
----------------- --------------------------------------------------------------------------------------------------------------------------------
                3 Development Channel                                                                                                             
                1 General                                                                                                                         
                5 Admin                                                                                                                           

*/

/* 18.
*/
select chat_message.date_time, message_contents
from chat_message
left join hardware_request
on chat_message.date_time = hardware_request.date_time;
/*
Result:
DATE_TIME MESSAGE_CONTENTS                                                                
--------- --------------------------------------------------------------------------------
27-MAR-20 Lets do it                                                                      
26-MAR-20 Day two of testing, seems to work fine                                          
26-MAR-20 Can someone else try sending a message?                                         
26-MAR-20 Yo                                                                              
26-MAR-20 Thanks                                                                          
27-MAR-20 Anyone down for lunch today? Thinking pizza                                     
25-MAR-20 Looks like it. Probably have to do more testing                                 
25-MAR-20 This is a test message                                                          
25-MAR-20 :thumbsup:                                                                      
27-MAR-20 Check out general chat, lunch today if anyone wants it                          
25-MAR-20 Did you get the chat system working?                                            

11 rows selected. 

*/
