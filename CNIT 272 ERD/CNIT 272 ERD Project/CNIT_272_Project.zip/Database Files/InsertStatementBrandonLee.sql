insert into vc_commit values ('8237594878982345', 'master', 'Medical Insurance', TO_DATE('03-25-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), 'Test source code', 'Test Files', 'Test Reeason', '0000000000000001', 'Hardware-Ordering');
insert into vc_commit values ('3838484857575656', 'dev', 'Medical Insurance', TO_DATE('03-25-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), 'Test source code', 'Test Files', 'Test Reeason', '0000000000000002', 'Collocation');
insert into vc_commit values ('1010292938384747', 'fix-hardware-ordering', 'Medical Insurance', TO_DATE('03-25-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), 'Test source code', 'Test Files', 'Test Reeason', '0000000000000003', 'Hardware-Ordering');
insert into vc_commit values ('2929383829291010', 'master', 'Medical Insurance', TO_DATE('03-25-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), 'Test source code', 'Test Files', 'Test Reeason', '0000000000000004', 'Chat');
insert into vc_commit values ('2929383832929101', 'dev', 'Medical Insurance', TO_DATE('03-25-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), 'Test source code', 'Test Files', 'Test Reeason', '0000000000000005', 'Chat');
insert into vc_commit values ('9090878776766565', 'make-better-net', 'Medical Insurance', TO_DATE('03-25-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), 'Test source code', 'Test Files', 'Test Reeason', '0000000000000006', 'Neural-Net');
insert into vc_commit values ('2929383817172626', 'master', 'Medical Insurance', TO_DATE('03-25-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), 'Test source code', 'Test Files', 'Test Reeason', '0000000000000007', 'Collocation');
insert into vc_commit values ('9898767665654747', 'master', 'Medical Insurance', TO_DATE('03-25-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), 'Test source code', 'Test Files', 'Test Reeason', '0000000000000008', 'Frontend');
insert into vc_commit values ('2929383857576060', 'dev', 'Medical Insurance', TO_DATE('03-25-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), 'Test source code', 'Test Files', 'Test Reeason', '0000000000000009', 'Frontend');
insert into vc_commit values ('2929383847475959', 'perform-maintenance', 'Medical Insurance', TO_DATE('03-25-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), 'Test source code', 'Test Files', 'Test Reeason', '0000000000000010', 'Maintenance');

insert into vc_issue values ('2939483849492828', 'Moe','8282','1','Fever','Kelly', 'Hardware-Ordering', 'master');
insert into vc_issue values ('1828494928283737', 'Moe','2423','1','Fever','Hn', 'Collocation', 'dev');
insert into vc_issue values ('1010292928282828', 'Moe','2534','1','Fever','JKJK', 'Hardware-Ordering', 'fix-hardware-ordering');
insert into vc_issue values ('1919191919191919', 'Moe','3424','1','Fever','THODH', 'Chat', 'master');
insert into vc_issue values ('2828282828282828', 'Moe','7575','1','Fever','KOHN', 'Chat', 'dev');
insert into vc_issue values ('3737373737373737', 'Moe','8989','1','Fever','Marco', 'Neural-Net', 'make-better-net');
insert into vc_issue values ('4747474747474747', 'Moe','1212','1','Fever','Polo', 'Collocation', 'master');
insert into vc_issue values ('5757575757575757', 'Moe','2323','1','Fever','Rahul', 'Frontend', 'master');
insert into vc_issue values ('6767676767676767', 'Moe','3434','1','Fever','Koi', 'Frontend', 'dev');
insert into vc_issue values ('7777777777777777', 'Moe','4545','1','Fever','Thul', 'Maintenance', 'perform-maintenance');


insert into support_ticket values ('2929373749491818','Hulk', TO_DATE('07-19-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), '1919', 'Timmy', '0000000000000001','Hardware-Ordering','master','2939483849492828'); 
insert into support_ticket values ('1515151515151515','Hulk', TO_DATE('07-19-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), '1919', 'Timmy', '0000000000000002','Collocation','dev','1828494928283737'); 
insert into support_ticket values ('2525252525252522','Hulk', TO_DATE('07-19-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), '1919', 'Timmy', '0000000000000003','Hardware-Ordering','fix-hardware-ordering','1010292928282828'); 
insert into support_ticket values ('3636363636363636','Hulk', TO_DATE('07-19-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), '1919', 'Timmy', '0000000000000004','Chat','master','1919191919191919'); 
insert into support_ticket values ('4646464646464646','Hulk', TO_DATE('07-19-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), '1919', 'Timmy', '0000000000000005','Chat','dev','2828282828282828'); 
insert into support_ticket values ('5656565656565656','Hulk', TO_DATE('07-19-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), '1919', 'Timmy', '0000000000000006','Neural-Net','make-better-net','3737373737373737'); 
insert into support_ticket values ('1010101010101010','Hulk', TO_DATE('07-19-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), '1919', 'Timmy', '0000000000000007','Collocation','master','4747474747474747'); 
insert into support_ticket values ('1919191919191919','Hulk', TO_DATE('07-19-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), '1919', 'Timmy', '0000000000000008','Frontend','master','5757575757575757'); 
insert into support_ticket values ('2828282828282828','Hulk', TO_DATE('07-19-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), '1919', 'Timmy', '0000000000000009','Frontend','dev','6767676767676767'); 
insert into support_ticket values ('3838383838383838','Hulk', TO_DATE('07-19-2019 15:00:00', 'MM-DD-YYYY HH24:MI:SS'), '1919', 'Timmy', '0000000000000010','Maintenance','perform-maintenance','7777777777777777'); 
