/*
Jack Doble
******************************************************
Query 25
*/
select * 
from server
where server_id = 20;

/*
Before:

SERVER_ID  MAKE            MODEL           SPECIFICATIONS                                                                   DATE_TO_S PROCESSES                                          REQUEST_ID       VENDOR_ID                     
---------- --------------- --------------- -------------------------------------------------------------------------------- --------- -------------------------------------------------- ---------------- ----------------
10         HP              M160            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-DEC-16 Intl,Runtime,Xp                                    0000000000000007 0000000000000004                                                                                                                                                                                                                                                             HP                                                                                                                                                                                                                                                               M160                                                                                                                                                                                                                                                             Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-DEC-16 Intl,Runtime,Xp                                                                                                                                                                                                                                                  0000000000000007 0000000000000004                                                                                                                                                                                                                                                     Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-DEC-16 Intl,Runtime,Xp                                                                                                                                                                                                                                                  0000000000000007 0000000000000004

I am deleting this row because this server is no longer in service.
*/
delete from server
where server_id = 10;

select * 
from server
where server_id = 10;
/*
Result:

1 row deleted.

no rows selected
*/
/*
******************************************************
Query 26
*/
select *
from server;
/*
Before:

SERVER_ID  MAKE            MODEL           SPECIFICATIONS                                                                   DATE_TO_S PROCESSES                                          REQUEST_ID       VENDOR_ID                      
---------- --------------- --------------- -------------------------------------------------------------------------------- --------- -------------------------------------------------- ---------------- ---------------- 
20         Dell            M170            Intel Xeon E5-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-NOV-19 Intl,Mgmt,Runtime,Xp                               0000000000000008 0000000000000003         
30         Cisco           M260            Intel Xeon E1-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             23-DEC-16 Intl,Mgmt,Runtime,Xp                               0000000000000009 0000000000000002           
40         Microsoft       M1990           Intel Xeon E2-2635 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             21-MAY-18 Intl,Mgmt,Runtime,Xp                               0000000000000010 0000000000000001       
50         Dell            M170            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-FEB-16 Intl,Mgmt,Runtime                                  0000000000000006 0000000000000005          
60         Dell            M160            Intel Xeon E5-2650 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-AUG-17 Intl,Mgmt,Runtime,Xp                               0000000000000005 0000000000000006         
70         HP              M190            Intel Xeon E2-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             02-DEC-16 Intl,Mgmt,Runtime,Xp                               0000000000000004 0000000000000007          
80         HP              M130            Intel Xeon E4-3630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-DEC-17 Intl,Mgmt,Runtime,Xp                               0000000000000003 0000000000000010          
90         Microsoft       B360            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-DEC-17 Intl,Mgmt,Xp                                       0000000000000002 0000000000000009           
100        HP              M250            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             02-NOV-16 Mgmt,Runtime,Xp                                    0000000000000001 0000000000000008          

9 rows selected. 

Currently there is no telling what operating system version each server has. This new column
allows for better documentation of each server.
*/
alter table server
add operating_system varchar2(256);

select *
from server;
/*
Result:

Table SERVER altered.

SERVER_ID  MAKE            MODEL           SPECIFICATIONS                                                                   DATE_TO_S PROCESSES                                          REQUEST_ID       VENDOR_ID        OPERATING_SYSTEM              
---------- --------------- --------------- -------------------------------------------------------------------------------- --------- -------------------------------------------------- ---------------- ---------------- ------------------------------
20         Dell            M170            Intel Xeon E5-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-NOV-19 Intl,Mgmt,Runtime,Xp                               0000000000000008 0000000000000003           
30         Cisco           M260            Intel Xeon E1-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             23-DEC-16 Intl,Mgmt,Runtime,Xp                               0000000000000009 0000000000000002          
40         Microsoft       M1990           Intel Xeon E2-2635 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             21-MAY-18 Intl,Mgmt,Runtime,Xp                               0000000000000010 0000000000000001      
50         Dell            M170            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-FEB-16 Intl,Mgmt,Runtime                                  0000000000000006 0000000000000005       
60         Dell            M160            Intel Xeon E5-2650 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-AUG-17 Intl,Mgmt,Runtime,Xp                               0000000000000005 0000000000000006       
70         HP              M190            Intel Xeon E2-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             02-DEC-16 Intl,Mgmt,Runtime,Xp                               0000000000000004 0000000000000007           
80         HP              M130            Intel Xeon E4-3630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-DEC-17 Intl,Mgmt,Runtime,Xp                               0000000000000003 0000000000000010        
90         Microsoft       B360            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-DEC-17 Intl,Mgmt,Xp                                       0000000000000002 0000000000000009      
100        HP              M250            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             02-NOV-16 Mgmt,Runtime,Xp                                    0000000000000001 0000000000000008         

9 rows selected. 
*/
/*
******************************************************
Query 27
*/
select *
from server;
/*
Before:

SERVER_ID  MAKE            MODEL           SPECIFICATIONS                                                                   DATE_TO_S PROCESSES                                          REQUEST_ID       VENDOR_ID        OPERATING_SYSTEM              
---------- --------------- --------------- -------------------------------------------------------------------------------- --------- -------------------------------------------------- ---------------- ---------------- ------------------------------
20         Dell            M170            Intel Xeon E5-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-NOV-19 Intl,Mgmt,Runtime,Xp                               0000000000000008 0000000000000003           
30         Cisco           M260            Intel Xeon E1-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             23-DEC-16 Intl,Mgmt,Runtime,Xp                               0000000000000009 0000000000000002          
40         Microsoft       M1990           Intel Xeon E2-2635 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             21-MAY-18 Intl,Mgmt,Runtime,Xp                               0000000000000010 0000000000000001      
50         Dell            M170            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-FEB-16 Intl,Mgmt,Runtime                                  0000000000000006 0000000000000005       
60         Dell            M160            Intel Xeon E5-2650 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-AUG-17 Intl,Mgmt,Runtime,Xp                               0000000000000005 0000000000000006       
70         HP              M190            Intel Xeon E2-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             02-DEC-16 Intl,Mgmt,Runtime,Xp                               0000000000000004 0000000000000007           
80         HP              M130            Intel Xeon E4-3630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-DEC-17 Intl,Mgmt,Runtime,Xp                               0000000000000003 0000000000000010        
90         Microsoft       B360            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-DEC-17 Intl,Mgmt,Xp                                       0000000000000002 0000000000000009      
100        HP              M250            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             02-NOV-16 Mgmt,Runtime,Xp                                    0000000000000001 0000000000000008         

9 rows selected. 

Each row will be updated to show each server has Debian Server 10.3.0 installed.
*/
update server
set operating_system = 'Debian Server 10.3.0';

select *
from server;
/*
Result:

SERVER_ID  MAKE            MODEL           SPECIFICATIONS                                                                   DATE_TO_S PROCESSES                                          REQUEST_ID       VENDOR_ID        OPERATING_SYSTEM              
---------- --------------- --------------- -------------------------------------------------------------------------------- --------- -------------------------------------------------- ---------------- ---------------- ------------------------------
20         Dell            M170            Intel Xeon E5-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-NOV-19 Intl,Mgmt,Runtime,Xp                               0000000000000008 0000000000000003 Debian Server 10.3.0          
30         Cisco           M260            Intel Xeon E1-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             23-DEC-16 Intl,Mgmt,Runtime,Xp                               0000000000000009 0000000000000002 Debian Server 10.3.0          
40         Microsoft       M1990           Intel Xeon E2-2635 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             21-MAY-18 Intl,Mgmt,Runtime,Xp                               0000000000000010 0000000000000001 Debian Server 10.3.0          
50         Dell            M170            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-FEB-16 Intl,Mgmt,Runtime                                  0000000000000006 0000000000000005 Debian Server 10.3.0          
60         Dell            M160            Intel Xeon E5-2650 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-AUG-17 Intl,Mgmt,Runtime,Xp                               0000000000000005 0000000000000006 Debian Server 10.3.0          
70         HP              M190            Intel Xeon E2-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             02-DEC-16 Intl,Mgmt,Runtime,Xp                               0000000000000004 0000000000000007 Debian Server 10.3.0          
80         HP              M130            Intel Xeon E4-3630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-DEC-17 Intl,Mgmt,Runtime,Xp                               0000000000000003 0000000000000010 Debian Server 10.3.0          
90         Microsoft       M360            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-DEC-17 Intl,Mgmt,Xp                                       0000000000000002 0000000000000009 Debian Server 10.3.0          
100        HP              M250            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             02-NOV-16 Mgmt,Runtime,Xp                                    0000000000000001 0000000000000008 Debian Server 10.3.0          

9 rows selected. 
*/
/*
******************************************************
Query 28
*/
select *
from server;
/*
Before:

SERVER_ID  MAKE            MODEL           SPECIFICATIONS                                                                   DATE_TO_S PROCESSES                                          REQUEST_ID       VENDOR_ID        OPERATING_SYSTEM              
---------- --------------- --------------- -------------------------------------------------------------------------------- --------- -------------------------------------------------- ---------------- ---------------- ------------------------------
20         Dell            M170            Intel Xeon E5-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-NOV-19 Intl,Mgmt,Runtime,Xp                               0000000000000008 0000000000000003 Debian Server 10.3.0          
30         Cisco           M260            Intel Xeon E1-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             23-DEC-16 Intl,Mgmt,Runtime,Xp                               0000000000000009 0000000000000002 Debian Server 10.3.0          
40         Microsoft       M1990           Intel Xeon E2-2635 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             21-MAY-18 Intl,Mgmt,Runtime,Xp                               0000000000000010 0000000000000001 Debian Server 10.3.0          
50         Dell            M170            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-FEB-16 Intl,Mgmt,Runtime                                  0000000000000006 0000000000000005 Debian Server 10.3.0          
60         Dell            M160            Intel Xeon E5-2650 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-AUG-17 Intl,Mgmt,Runtime,Xp                               0000000000000005 0000000000000006 Debian Server 10.3.0          
70         HP              M190            Intel Xeon E2-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             02-DEC-16 Intl,Mgmt,Runtime,Xp                               0000000000000004 0000000000000007 Debian Server 10.3.0          
80         HP              M130            Intel Xeon E4-3630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-DEC-17 Intl,Mgmt,Runtime,Xp                               0000000000000003 0000000000000010 Debian Server 10.3.0          
90         Microsoft       M360            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-DEC-17 Intl,Mgmt,Xp                                       0000000000000002 0000000000000009 Debian Server 10.3.0          
100        HP              M250            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             02-NOV-16 Mgmt,Runtime,Xp                                    0000000000000001 0000000000000008 Debian Server 10.3.0          

9 rows selected. 

This record was updated to reflect a change to a different server model.
*/
update server
set model = 'B' || substr(model,2,length(model))
where server_id = 90;

COLUMN server_id FORMAT A10;
COLUMN make FORMAT A15;
COLUMN model FORMAT A15;
COLUMN processes FORMAT A30;
COLUMN operating_system FORMAT A30;

select *
from server;
/*
Result:

SERVER_ID  MAKE            MODEL           SPECIFICATIONS                                                                   DATE_TO_S PROCESSES                                          REQUEST_ID       VENDOR_ID        OPERATING_SYSTEM              
---------- --------------- --------------- -------------------------------------------------------------------------------- --------- -------------------------------------------------- ---------------- ---------------- ------------------------------
20         Dell            M170            Intel Xeon E5-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-NOV-19 Intl,Mgmt,Runtime,Xp                               0000000000000008 0000000000000003 Debian Server 10.3.0          
30         Cisco           M260            Intel Xeon E1-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             23-DEC-16 Intl,Mgmt,Runtime,Xp                               0000000000000009 0000000000000002 Debian Server 10.3.0          
40         Microsoft       M1990           Intel Xeon E2-2635 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             21-MAY-18 Intl,Mgmt,Runtime,Xp                               0000000000000010 0000000000000001 Debian Server 10.3.0          
50         Dell            M170            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-FEB-16 Intl,Mgmt,Runtime                                  0000000000000006 0000000000000005 Debian Server 10.3.0          
60         Dell            M160            Intel Xeon E5-2650 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-AUG-17 Intl,Mgmt,Runtime,Xp                               0000000000000005 0000000000000006 Debian Server 10.3.0          
70         HP              M190            Intel Xeon E2-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             02-DEC-16 Intl,Mgmt,Runtime,Xp                               0000000000000004 0000000000000007 Debian Server 10.3.0          
80         HP              M130            Intel Xeon E4-3630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             12-DEC-17 Intl,Mgmt,Runtime,Xp                               0000000000000003 0000000000000010 Debian Server 10.3.0          
90         Microsoft       B360            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             22-DEC-17 Intl,Mgmt,Xp                                       0000000000000002 0000000000000009 Debian Server 10.3.0          
100        HP              M250            Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink             02-NOV-16 Mgmt,Runtime,Xp                                    0000000000000001 0000000000000008 Debian Server 10.3.0          

9 rows selected. 
*/
/*
******************************************************
Query 29
*/
create view projects2020 as
select project_name, creator, creation_date, url, description
from vc_project
where creation_date between '1-JAN-20' and '31-DEC-2020';

create index creator_index
on vc_project (creator);

create unique index creationdate_index
on vc_project (creation_date);

COLUMN project_name FORMAT A20;
COLUMN creator FORMAT A20;
COLUMN url FORMAT A90;
COLUMN description FORMAT A400;

select *
from vc_project;
/*
Result:

PROJECT_NAME         CREATOR              CREATION_ URL                                                                                        DESCRIPTION                                                                                                                                                                                                                                                                                                                                                                                                     
-------------------- -------------------- --------- ------------------------------------------------------------------------------------------ ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Hardware-Ordering                                   https://github.com/BoilerSolutions/MSAS/projects/1                                         Anything related to Hardware Ordering. This is where issues involving the Hardware Ordering System will be fixed.                                                                                                                                                                                                                                                                                               
Collocation          Nicole Hands         27-APR-18                                                                                            Anything related to Collocation. This is where problems related to Collocation not working will be fixed.                                                                                                                                                                                                                                                                                                       
Chat                                      20-NOV-18 https://github.com/BoilerSolutions/MSAS/projects/3                                         Anything related to the Chat. This is where new features will be added so users can better communicate.                                                                                                                                                                                                                                                                                                         
Neural-Net           Victor Barlow        26-JUL-18 https://github.com/BoilerSolutions/MSAS/projects/4                                         Anything related to the Neural Net. This is where the Neural Network will be trained and used.                                                                                                                                                                                                                                                                                                                  
Server               Dawn Laux            02-FEB-16                                                                                            Anything related to the Servers. This could involve specs or status of the servers.                                                                                                                                                                                                                                                                                                                             
Frontend             Robert Deadman                 https://github.com/BoilerSolutions/MSAS/projects/6                                         Anything related to the Frontend of the service. This is where the website development happens.                                                                                                                                                                                                                                                                                                                 
Database             Dominic Kao          10-SEP-17                                                                                            Anything related to the Database. This could involve adding items to it or doing a new version.                                                                                                                                                                                                                                                                                                                 
Support              Eric Matson          23-AUG-20                                                                                            Anything related to the Support of users. This is where the support team will interact with customers.                                                                                                                                                                                                                                                                                                          
Version-Control      Guity Ravai          18-DEC-19 https://github.com/BoilerSolutions/MSAS/projects/9                                         Anything related to Version Control. This could be errors or collaboration requests.                                                                                                                                                                                                                                                                                                                            
Maintenance          Phillip Rawles       02-APR-15 https://github.com/BoilerSolutions/MSAS/projects/10                                        Anything related to the Maintenance of the system.                                                                                                                                                                                                                                                                                                                                                              

10 rows selected. 
*/
/*
******************************************************
Query 30
*/
COLUMN first_name FORMAT A20;
COLUMN last_name FORMAT A20;

select first_name,last_name,permitted_access_level
from employee
where permitted_access_level in (7,8,9);
/*
Result:

 FIRST_NAME           LAST_NAME            PERMITTED_ACCESS_LEVEL
-------------------- -------------------- ----------------------
Dawn                 Laux                                      9
Dominic              Kao                                       9
Eric                 Matson                                    7
Alejandra            Magana                                    8                                                                                                                                                                                                                                                    Magana                                                                                                                                                                                                                                                                                8
*/
