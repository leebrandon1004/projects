/*
Garrett Laman
Queries 7-12
*******************************************************************************************************************************
Query 7:
*/
COL EMPLOYEE_ID FORMAT a15;
COL FIRST_NAME FORMAT a15;
COL LAST_NAME FORMAT a15;
COL HIRE_DATE FORMAT a15;
COL BIRTH_DATE FORMAT a15;
COL PERMITTED_ACCESS_LEVEL FORMAT a15;
SELECT EMPLOYEE_ID, FIRST_NAME, LAST_NAME, HIRE_DATE, BIRTH_DATE, PERMITTED_ACCESS_LEVEL
FROM EMPLOYEE
WHERE BIRTH_DATE = (SELECT MIN(BIRTH_DATE)
                    FROM EMPLOYEE);
/*
Results:
EMPLOYEE_ID     FIRST_NAME      LAST_NAME       HIRE_DATE       BIRTH_DATE      PERMITTED_ACCES
--------------- --------------- --------------- --------------- --------------- ---------------
0000000000000007 Guity           Ravai           14-NOV-11       07-SEP-65                     6
*******************************************************************************************************************************
Query 8:
*/
SELECT COUNT(CHAT_ROOM_NAME), CHAT_ROOM_NAME
FROM CHAT_MESSAGE
GROUP BY CHAT_ROOM_NAME;
/*
Results:
COUNT(CHAT_ROOM_NAME) CHAT_ROOM_NAME                                                                                                                  
--------------------- ---------------------
                    2 General                                                                                                                         
                    1 Admin                                                                                                                           
                    8 Development Channel                                                                                                             
*******************************************************************************************************************************
Query 9:
*/
SELECT SUM(ACCURACY*TRAINING_DURATION) AS ACCURACY_TIMES_DURATION
FROM CLAIM_NET;
/*
Results:
ACCURACY_TIMES_DURATION
-----------------------
                4451.99
                
I couldn't find any columns that would work better for this.. The calculated field doesn't actually show anything, but there it is
********************************************************************************************************************************
Query 10:
*/
SELECT VENDOR_ID, AVG(HARDWARE_PRICE)
FROM HARDWARE_REQUEST
GROUP BY VENDOR_ID;
/*
Results:

VENDOR_ID        AVG(HARDWARE_PRICE)
---------------- -------------------
0000000000000003                  77
0000000000000007                  25
0000000000000002                   8
0000000000000001                  11
0000000000000004                  50
0000000000000010                  20
0000000000000005                   7
0000000000000006                  16
0000000000000008                  10
0000000000000009                   8

10 rows selected. 
********************************************************************************************************************************
Query 11:
*/
SELECT CHAT_ROOM_NAME, COUNT(CHAT_ROOM_NAME)
FROM CHAT_MESSAGE
GROUP BY CHAT_ROOM_NAME
HAVING (COUNT(CHAT_ROOM_NAME)> 1);
/*
Result:

CHAT_ROOM_NAME                                           COUNT(CHAT_ROOM_NAME)
-------------------------------------------------------- ---------------------
General                                                  2
Development Channel                                      8
********************************************************************************************************************************
Query 12:
*/
SELECT CHAT_ROOM_NAME, COUNT(CHAT_ROOM_NAME)
FROM CHAT_MESSAGE
WHERE DATE_TIME >= '26-MAR-2020'
GROUP BY CHAT_ROOM_NAME
HAVING (COUNT(CHAT_ROOM_NAME)> 1);
/*
Result:
CHAT_ROOM_NAME                                           COUNT(CHAT_ROOM_NAME)
-------------------------------------------------------- ---------------------
General                                                  2
Development Channel                                      4
*/
