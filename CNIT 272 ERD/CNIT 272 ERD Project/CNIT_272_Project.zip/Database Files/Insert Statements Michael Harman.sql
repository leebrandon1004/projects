
--Hardware Vendor Table
insert into Hardware_Vendor values 
('0000000000000001','Hands Hardy Hardware','West Lafayette', 'IN', 'Heavilon Hall','Hands, Nicole','7654547899');
insert into Hardware_Vendor values 
('0000000000000002','JJ Tools Inc','Kansas City', 'MO', '3321 Bald Street','Jackson, James','5436667890');
insert into Hardware_Vendor values 
('0000000000000003','Hammers Deluxe','Tucson', 'AZ', '4563 Hammer Rd','Claw, Bob','5363990367');
insert into Hardware_Vendor values 
('0000000000000004','Knock on Wood','Modesto', 'CA', '43 Wood Blvd','Tree, Jeff','2376548232');
insert into Hardware_Vendor values 
('0000000000000005','Tools For You','Hialeah', 'FL', '123 Plain Rd','Ross, Bob','3589993456');
insert into Hardware_Vendor values 
('0000000000000006','Lumber Co','Boston', 'MA', '8657 Log Drive','Lumber, Jack','9992765543');
insert into Hardware_Vendor values 
('0000000000000007','Drill It','Scottsdale', 'AZ', 'Rubble Road','Gravel, Tom','5763268754');
insert into Hardware_Vendor values 
('0000000000000008','Bills Hard Wood','Orlando', 'FL', '656 Rod Street','Long, Steve','5684665458');
insert into Hardware_Vendor values 
('0000000000000009','Drill Everything','Cleveland', 'OH', '3321 Rocky Road','Buzz, George','5678907656');
insert into Hardware_Vendor values 
('0000000000000010','Hello Decks','Tampa', 'FL', '2222 Riverside Lane','Bud, Jack','8765778900');

--Hardware Request Table
insert into Hardware_Request values
('0000000000000001',to_date('10-12-2019', 'MM-DD-YYYY'),'Box of Nails','10','4','0000000000000005','0000000000000008');
insert into Hardware_Request values
('0000000000000002',to_date('11-24-2019', 'MM-DD-YYYY'),'Screws','8','2','0000000000000006','0000000000000009');
insert into Hardware_Request values
('0000000000000003',to_date('05-13-2019', 'MM-DD-YYYY'),'2x4 Wood','20','8','0000000000000007','0000000000000010');
insert into Hardware_Request values
('0000000000000004',to_date('01-28-2019', 'MM-DD-YYYY'),'Custom Wood Frame','25','10','0000000000000008','0000000000000007');
insert into Hardware_Request values
('0000000000000005',to_date('10-13-2019', 'MM-DD-YYYY'),'Hammer','16','8','0000000000000009','0000000000000006');
insert into Hardware_Request values
('0000000000000006',to_date('08-16-2019', 'MM-DD-YYYY'),'Drill','7','5','0000000000000010','0000000000000005');
insert into Hardware_Request values
('0000000000000007',to_date('10-22-2019', 'MM-DD-YYYY'),'Metal Hinge','50','33','0000000000000004','0000000000000004');
insert into Hardware_Request values
('0000000000000008',to_date('03-08-2019', 'MM-DD-YYYY'),'Bolts','77','20','0000000000000003','0000000000000003');
insert into Hardware_Request values
('0000000000000009',to_date('11-05-2019', 'MM-DD-YYYY'),'Plywood Crate','8','6','0000000000000002','0000000000000002');
insert into Hardware_Request values
('0000000000000010',to_date('06-12-2019', 'MM-DD-YYYY'),'Nailgun','11','4','0000000000000001','0000000000000001');

--Server Table
insert into server values
('10','HP','M160','Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink',to_date('12-22-2016', 'MM-DD-YYYY'),'Intl,Runtime,Xp','0000000000000007','0000000000000004');
insert into server values
('20','Dell','M170','Intel Xeon E5-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink',to_date('11-12-2019', 'MM-DD-YYYY'),'Intl,Mgmt,Runtime,Xp','0000000000000008','0000000000000003');
insert into server values
('30','Cisco','M260','Intel Xeon E1-2230 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink',to_date('12-23-2016', 'MM-DD-YYYY'),'Intl,Mgmt,Runtime,Xp','0000000000000009','0000000000000002');
insert into server values
('40','Microsoft','M1990','Intel Xeon E2-2635 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink',to_date('05-21-2018', 'MM-DD-YYYY'),'Intl,Mgmt,Runtime,Xp','0000000000000010','0000000000000001');
insert into server values
('50','Dell','M170','Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink',to_date('02-12-2016', 'MM-DD-YYYY'),'Intl,Mgmt,Runtime','0000000000000006','0000000000000005');
insert into server values
('60','Dell','M160','Intel Xeon E5-2650 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink',to_date('08-22-2017', 'MM-DD-YYYY'),'Intl,Mgmt,Runtime,Xp','0000000000000005','0000000000000006');
insert into server values
('70','HP','M190','Intel Xeon E2-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink',to_date('12-02-2016', 'MM-DD-YYYY'),'Intl,Mgmt,Runtime,Xp','0000000000000004','0000000000000007');
insert into server values
('80','HP','M130','Intel Xeon E4-3630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink',to_date('12-12-2017', 'MM-DD-YYYY'),'Intl,Mgmt,Runtime,Xp','0000000000000003','0000000000000010');
insert into server values
('90','Microsoft','M360','Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink',to_date('12-22-2017', 'MM-DD-YYYY'),'Intl,Mgmt,Xp','0000000000000002','0000000000000009');
insert into server values
('100','HP','M250','Intel Xeon E5-2630 v3,128GB DDR4 RAM,7.2TB Disk Space,100mbps uplink',to_date('11-02-2016', 'MM-DD-YYYY'),'Mgmt,Runtime,Xp','0000000000000001','0000000000000008');

